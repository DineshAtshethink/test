
module.exports.logBody = (req,...args) =>{
    return JSON.stringify({
        host: req.hostname,
        method : req.route.methods,
        route : req.route.path,
        message: [...args]
    });
}