const { createLogger, format, transports } = require('winston');
const {time} = require("speakeasy");
const { combine, timestamp, label, printf, json,ms} = format;

class NestLog {

    constructor() {
        this.logger = Object.is(process.env.NODE_ENV, 'Development') ? this.debugLogger() : this.productionLogger();
     }

    debugLogger(){
        return createLogger({
            label:{label:'Nest Market'},
            format: combine(
                format.colorize(),
                timestamp(),
                ms(),
               printf(({ level, message, timestamp, ms}) => `${timestamp} [${level}]: ${message} - ${ms}`)
            ),
            transports: [new transports.Console(),
                new transports.File({
                    filename: 'error.log',
                    level: 'error',
                    format: json()
                })]
        });
    }

    productionLogger(){
        return createLogger({
            format: combine(
                label({label:'Nest Market'}),
                timestamp(),
                ms()
            ),
            transports: [
                new transports.File({
                    filename: 'error.log',
                    level: 'error',
                    format: json()
                }),
                new transports.File({
                    filename: 'combined.log',
                    level: 'info',
                    format: json()
                }),
                new transports.Http({
                    level: 'warn',
                    format: json()
                }),
                new transports.Console({
                    level: 'info',
                    format: combine(
                        format.colorize(),
                        format.simple()
                    )
                })
            ]
        });
    }
}

module.exports = NestLog;