const {Schema} = require('mongoose');
const mongoose = require('mongoose');

const SellerCommission = new Schema({
    minAmount:{
        type:Number,
        unique:true,
        required:true
    },
    maxAmount:{
        type:Number,
        unique:true,
        required:true
    },
    percentage:{
        type:Number,
        required:true
    },
    status:{
        type:String,
        enum:['Active','Inactive'],
        default:'Active'
    },
    createdAt:{
        type:Date
    },
    updatedAt:{
        type:Date
    }
});

SellerCommission.pre('save', function(next){
    let currentDate = new Date();
    this.updatedAt = currentDate;
    if(!this.createdAt){
        this.createdAt = currentDate;
    }
    next();
});

module.exports.SellerSchema = mongoose.model('SellerCommission',SellerCommission);