""/*
* TODO: 1.nest commission model
* */
const mongoose = require('mongoose');
const {Schema} = mongoose;

const commissionSchema = new Schema({
    userId: {
        type: String,
        minlength: [5, 'UserId must be at least 5 characters.'],
        required: true
    },
    commissionType: {
        type: String,
        enum: {
            values: ['Buyer', 'Seller'],
            message: 'Commission type must be Buyer or Seller.'
        },
        required: true
    },
    commissionPercent: {
        type: Number,
        default: 0,
        required: true
    },
    commissionValue:{
        type: Number,
        default: 0,
        required: true
    },
    actualAmount: {
        type: Number,
        required: true
    },
    totalAmount: {
        type: Number,
        required: true
    },
    gridId: {
        type: String,
        minlength: [5, 'GridId must be at least 5 characters.'],
    },
    commissionId: {
        type: String,
        minlength: [5, 'CommissionId must be at least 5 characters.'],
        required: true
    },
    status: {
        type: String,
        enum: {
            values: ['pending', 'completed'],
            message: 'Commission status must be pending or completed.'
        },
        default: 'pending'
    },
    createdAt: {
        type: Date
    },
    updatedAt: {
        type: Date
    }
});

commissionSchema.pre('save', function (next) {
    if(!this.createdAt) {
        this.createdAt = Date.now();
    }
    this.updatedAt = Date.now();
    next();
});

module.exports = mongoose.model('Commission', commissionSchema);
