const mongoose = require('mongoose');
const {Schema} = require('mongoose');

const otpSchema = new Schema({
    secret: {
        type:String,
        required: true
    },
    otp:{
        type:Number,
        required: true
    },
    userId:{
        type:String,
        required:true
    },
    createdAt:{
        type:Date,
        default: Date.now(),
        required: true
    }
});

module.exports = mongoose.model('Otp',otpSchema);