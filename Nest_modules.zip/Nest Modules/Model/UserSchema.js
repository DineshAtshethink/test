const mongoose = require("mongoose");
const bcrypt = require("bcrypt");
const saltRounds = 8;
const {Schema} = mongoose;

const userSchema = new Schema({
    firstName: {
        type: String,
        minlength: [3, "min length of first name should be 1"]
    },
    lastName: {
        type: String,
        minlength: [1, "min length of first name should be 1"]
    },
    emailID: {
        type: String,
        lowercase: true,
        unique: true,
        trim: true,
        validate: {
            validator: function (v) {
                return /^([\w-\.]+@([\w-]+\.)+[\w-]{2,4})?$/.test(v);
            },
            message: props => `${props.value} is not a valid email`
        },
        required: true
    },
    age: {
        type: Number,
        default: 0
    },
    mobile: {
        type: Number,
        default: 0
    },
    password: {
        type: String,
        required: true,
    },
    source: {
        type: String,
        enum: {
            values: ["Mobile App", "Google", "Facebook", "Apple"],
            message: '{VALUE} is not a valid sourc'
        },
        required: true
    },
    role: {
        type: String,
        enum: {
            values: ["Admin", "User"],
            message: '{VALUE} is not a valid role'
        },
        default: "User"
    },
    favourites: {
        type: Array
    },
    wallet: {
        id: {
            type: String,
            unique: true
        },
        amount: {
            type: Number,
            default: 0
        }
    },
    status: {
        type: String,
        default: "Active",
        enum: {
            values: ["Active", "Inactive", "Deleted"],
            message: '{VALUE} is not a valid status'
        }
    },
    accessToken: {
        type: String
    },
    accountDetails: {
        accountName: {
            type: String,
            default: ""
        },
        accountNumber: {
            type: Number,
            default: 0
        },
        routingNumber: {
            type: Number,
            default: 0
        }
    },
    createdAt: {
        type: Date
    },
    updatedAt: {
        type: Date
    }
});

userSchema.pre('validate', function (next) {
    console.log("pre validate - password", this.password);
    return new Promise(async (resolve, reject) => {
        if(!this.password && source==='Mobile App') {
            if (/^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{6,16}$/.test(this.password)) {
                this.password = await bcrypt.hash(this.password, saltRounds);
                resolve(next());
            } else {
                reject(new Error("Password should have 6 to 16 characters.Password should contain atleast one number and one special character"));
            }
        }
        else{
            resolve(next());
        }
    });
});



userSchema.pre('save',async function (next) {
    let currentDate = new Date();
    this.updatedAt = currentDate;
    if (!this.createdAt) {
        this.createdAt = currentDate;
        this.password = await bcrypt.hash(this.password, saltRounds);
    }
    next();
});

module.exports = mongoose.model("Users", userSchema);