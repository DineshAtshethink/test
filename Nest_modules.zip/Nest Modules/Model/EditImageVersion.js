const {Schema} = require('mongoose')
const mongoose = require("mongoose");

const EditImageVersion = Schema({
    imageDetails: {
        type:Object,
        required: true
    },
    uploadedUser: {
      type: String,
      required: true
    },
    editedAt: {
        type: Date,
        default: Date.now()
    }
})

module.exports = mongoose.model('EditImageVersion', EditImageVersion);