const { schema, Schema } = require("mongoose");
const mongoose = require("mongoose");

const PaymentSchema = new Schema({
  gridId: {
    type: String,
    minlength: [5, "Grid Id must be at least 5 characters long"],
    required: true,
  },
  paymentDate: {
    type: Date,
    default: new Date().toUTCString(),
  },
  clientSecret: {
    type: String,
  },
  sellerId: {
    type: String,
  },
  paymentIntentId: {
    type: String,
    minlength: [5, "Payment Intent Id must be at least 5 characters long"],
  },
  paymentUserId: {
    type: String,
    minlength: [5, "Payment User Id must be at least 5 characters long"],
    required: true,
  },
  status: {
    type: String,
    enum: {
      values: ["Incomplete", "Done", "Failed"],
      message: "Status must be Incomplete, Done or Failed",
    },
    default: "Incomplete",
  },
  walletTransactionId: {
    type: String,
  },
  appliedCoupon: {
    type: Object,
  },
  stripeAmount: {
    type: Number,
    default: 0,
  },
  totalAmount: {
    type: Number,
    required: true,
  },
});

PaymentSchema.pre("save", function (next) {
  this.paymentDate = new Date().toUTCString();
  next();
});

module.exports.Payment = new mongoose.model("Payment", PaymentSchema);
