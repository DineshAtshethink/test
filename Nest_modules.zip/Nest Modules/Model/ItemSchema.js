const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const itemSchema = Schema({
  title: {
    type: String,
    trim: true,
    minlength: [2, "The minimum length of the title is 2"],
    required: true,
  },
  originalImagePath: {
    type: String,
    required: true,
  },
  productImage: {
    type: String,
    required: true,
  },
  uploadedUser: {
    type: String,
    minlength: [8, "The minimum length of the username is 8"],
    required: true,
  },
  productLink: {
    type: String,
  },
  percentageSold: {
    type: Number,
    default: 0,
  },
  numberOfUnitsSold: {
    type: Number,
    default: 0,
  },
  price: {
    type: Number,
    min: [1, "The minimum price is 1"],
    required: true,
  },
  imageData: {
    type: Object,
    required: true,
  },
  isRenewed: {
    type: Boolean,
    default: false,
  },
  renewCount: {
    type: Number,
    default: 0,
  },
  category: {
    id: String,
    name: String,
    description: String,
  },
  events: {
    clickedCount: {
      type: Number,
      default: 0,
    },
  },
  pricePerUnit: {
    type: Number,
    default: 0,
  },
  gridLevels: {
    type: Number,
  },
  unitsForSale: {
    type: Number,
    default: 0,
  },
  condition: {
    name: String,
    description: String,
  },
  timePeriod: {
    type: Number,
  },
  description: {
    type: String,
  },
  uploadedAt: {
    type: Date,
  },
  status: {
    type: String,
    default: "Yet to be approved",
    enum: {
      values: ["Yet to be approved", "Approved", "Declined"],
      message: "Status is either Yet to be approved, Approved or Declined",
    },
  },
  isResellAllowed: {
    type: Boolean,
    default: false,
  },
  resellCount: {
    type: Number,
    default: 0,
  },
  paymentStatus: {
    type: String,
    default: "Yet to be Paid",
    enum: {
      values: ["Yet to be Paid", "Paid"],
      message: "Payment status is either Yet to be Paid or Paid",
    },
  },
  paidDate: {
    type: Date,
  },
});

itemSchema.pre("save", function (next) {
  this.uploadedAt = new Date().toUTCString();
  if (this.price < 1000) {
    next(new Error("The price is too low"));
  }
  next();
});

module.exports.Item = mongoose.model("Items", itemSchema);
