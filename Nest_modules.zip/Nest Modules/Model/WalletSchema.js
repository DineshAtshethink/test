const {Schema} = require('mongoose');
const mongoose = require('mongoose');

const WalletSchema = new Schema({
   transactionType: {
       type: String,
       enum:{
          values: ['Purchase', 'Redeem', 'Refund','Sales'],
          message: 'Invalid transaction type'
    },
       required:true
   },
    totalPurchaseUnits :{
       type:Number,
        min: [1, 'Minimum purchase units is 1'],
    },
    amount: {
       type: Number,
        default: 0,
        required: true
    },
    transactionStatus:{
      type: String,
      enum: {
         values: ['Pending', 'Paid', 'Failed', 'Refunded'],
          message: 'Invalid transaction status'
      },
      default: 'Pending'
    },
    updatedAt:{
       type: Date,
       default: new Date().toUTCString()
    },
    sellerId:{
       type: String,
        minlength: [1, 'Seller Id is required'],
    },
    userWalletId:{
       type: String,
        minlength: [1, 'User Wallet Id is required'],
       required: true
    }
});

WalletSchema.pre('save', function(next) {
    this.updatedAt = new Date().toUTCString();
    next();
});

module.exports.Wallet = mongoose.model('Wallet', WalletSchema);