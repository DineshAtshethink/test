const {Schema, mongo} = require('mongoose');
const mongoose = require('mongoose');


const AbuseSchema = new Schema({
    itemId: {
        type:String,
        required:true
    },
    comment:{
      type:String,
        required:true
    },
    reportedUser:{
      type:String,
      required:true
    },
    status:{
        type:String,
        enum: ['new','In-progress','closed'],
        default:'new'
    },
    createdAt:{
        type:Date,
        default:Date.now()
    },
    updatedAt:{
        type:Date,
        default:Date.now()
    }
});

module.exports.Abuse = mongoose.model('Abuse', AbuseSchema);