const {Schema} = require('mongoose');
const mongoose = require('mongoose');


const couponCodeSchema = new Schema({
    name : {
        type: String,
        required: true,
        unique:true
    },
    displayName : {
        type: String,
        required: true,
        unique:true
    },
    type: {
        type: String,
        enum: ["Flat","Percentage"],
        required: true
    },
    couponValue:{
        type:Number,
        default:0
    },
    fromDate: {
        type: Date,
        required: true
    },
    toDate: {
        type: Date,
        required: true
    },
    appliedUsers:{
        type: Array
    },
    status:{
      type: String,
      enum: ["Active","Inactive"],
      default: "Inactive"
    },
    createdAt:{
        type: Date,
        default: Date.now()
    },
    updatedAt:{
      type:Date,
      default: Date.now()
    }
});

module.exports = mongoose.model("CouponCode", couponCodeSchema);