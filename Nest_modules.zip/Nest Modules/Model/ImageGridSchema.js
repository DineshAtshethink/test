const mongoose = require("mongoose");
const { Schema } = require("mongoose");

const imageGridSchema = new Schema({
  actualPrice: {
    type: Number,
    min: [1, "actual Price should be greater than 0"],
    required: true,
  },
  updatedPrice: {
    type: Number,
  },
  smartKey: {
    type: Array,
    required: true,
  },
  paymentStatus: {
    type: String,
    default: "Pending",
    enum: {
      values: ["Pending", "Paid", "Failed"],
      message: "Payment Status should be Pending,Paid or Failed, got = {VALUE}",
    },
  },
  sellerId: {
    type: String,
  },
  purchaseLevel: {
    type: Number,
    enum: [1, 2],
    required: true,
  },
  purchaseUserId: {
    type: String,
    required: true,
  },
  itemId: {
    type: String,
    required: true,
  },
  isActive: {
    type: Boolean,
    default: true,
    required: true,
  },
  status: {
    type: String,
    default: "open",
    enum: ["open", "close"],
  },
  key: {
    type: Number,
    default: 0,
  },
  resellGridDetails: {
    type: Array,
    default: [],
  },
  createdAt: {
    type: Date,
    default: Date.now(),
    required: true,
  },
});

imageGridSchema.pre("save", function (next) {
  if (this.isNew) {
    this.createdAt = Date.now();
  }
  next();
});

module.exports = mongoose.model("imageGrids", imageGridSchema);
