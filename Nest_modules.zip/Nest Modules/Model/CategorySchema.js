const { Schema } = require("mongoose");
const mongoose = require("mongoose");

const categorySchema = new Schema({
  title: {
    type: String,
    unique: true,
    required: true,
  },
  categoryImage: {
    type: String,
  },
  iconLink: {
    type: String,
  },
  status: {
    type: String,
    enum: ["Active", "InActive"],
    default: "Active",
  },
  createdAt: {
    type: Date,
  },
  updatedAt: {
    type: Date,
  },
});

categorySchema.pre("save", function (next) {
  let currentDate = new Date().toUTCString();
  this.updatedAt = currentDate;
  if (!this.createdAt) {
    this.createdAt = currentDate;
  }
  next();
});


module.exports = mongoose.model("Category", categorySchema);
