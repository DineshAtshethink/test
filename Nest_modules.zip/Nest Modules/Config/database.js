const mongoose = require("mongoose");
const NestLog = require("../Logger/NestLog");
const logger= new NestLog().logger;

const {MONGO_URL} = process.env;

module.exports.connect = () =>{
    // Connecting to the database
    mongoose.connect(MONGO_URL, {
            useNewUrlParser: true,
            useUnifiedTopology: true
        }).then(() => logger.info("Successfully connected to database"))
        .catch((error) => {
            logger.info("database connection failed. exiting now...");
            console.error(error);
            process.exit(1);
        });
};