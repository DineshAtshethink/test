const express = require("express")
const items = require("../Controller/Items");
const category = require("../Controller/Category");
const couponCode = require("../Controller/CouponCode");
const userProfile = require("../Controller/UserProfile");
const auth = require('../Middleware/Auth');
const grids = require("../Controller/Grids");
const adminAbuse = require("../Controller/AdminAbuse");
const wallet = require("../Controller/Wallet");
const adminMarketplace = require('../Controller/AdminMarketPlace');
const payment = require('../Controller/Payment');
const commission = require('../Controller/NestCommission');

const app = express.Router();
app.use(auth);

app.use('/',items);
app.use('/',category);
app.use('/',couponCode);
app.use('/',userProfile);
app.use('/',grids);
app.use('/',adminAbuse);
app.use('/',wallet);
app.use('/',adminMarketplace);
app.use('/',payment);
app.use('/',commission);

module.exports = app;
