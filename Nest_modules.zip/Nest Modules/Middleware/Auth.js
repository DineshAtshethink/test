const jwt = require('jsonwebtoken');
const status = require('../Utils/NestHTTPStatusCodes');
const User = require('../Model/UserSchema');
const {response} = require('../Utils/Response');

const config = process.env;

const verifyToken = async (req, res, next) => {
    const token = req.body.token || req.query.token || req.headers['authorization'] === undefined ? '' : req.headers['authorization'].split(' ')[1];
    if (!token)
        return res.status(403).send(response(false, "A token is required for Middleware", {}));
    try {
        let isUserExist = await User.exists({accessToken: token});
        if (isUserExist) {
            req.user = jwt.verify(token, config.AUTH_SECRET);
        } else {
            return  res.status(status.UNAUTHORIZED).send(response(false, "invalid token", {}))
        }
    } catch (e) {
        return  res.status(status.UNAUTHORIZED).send(response(false, "invalid token", {err_msg:e.message}));
    }
    next();
}

module.exports = verifyToken;
