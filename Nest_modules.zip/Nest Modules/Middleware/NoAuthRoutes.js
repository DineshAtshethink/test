const signup = require("../Controller/signup");
const login = require("../Controller/login");
const express = require("express");
const forgetPassword = require("../Controller/ModifyPassword");
const invite = require("../Controller/invite");
const PaymentWebhook = require('../Controller/PaymentWebhook');
const app = express();

app.use("/", signup);
app.use("/", login);
app.use("/", forgetPassword);
app.use("/", invite);
app.use("/", PaymentWebhook);


module.exports = app;