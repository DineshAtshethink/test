const status = require('../Utils/NestHTTPStatusCodes');
const {response} = require('../Utils/Response');
const {filters} = require('../Utils/Filters');
const User = require('../Model/UserSchema');
const moment = require("moment");

module.exports.paginate2 = (model,option,filter) =>{
    return async(req,res,next)=>{
        const Regex = new RegExp('All','i');

        try {
            if (!Regex.test(req.query.id)) {
                let reqPage = req.query.page;
                let reqLimit = req.query.limit;
                const page = reqPage === undefined ? 1 : parseInt(reqPage);
                const limit = reqLimit === undefined ? 100 : parseInt(reqLimit);

                try {
                    const startIdx = (page - 1) * limit;
                    const endIdx = page * limit;

                    let opt;
                    opt = Object.assign({},option);
                    if(filter)
                    {
                        opt = Object.assign(opt,req.filter);
                    }

                    if(opt.isUserBased)
                        opt['uploadedUser'] = req.user.user_id;

                    console.table({opt});

                    console.log(opt);
                    req.result = await model.find(opt).limit(endIdx).skip(startIdx).sort({_id:-1}).exec();

                } catch (e) {
                    res.status(status.OK).send(response(false, e.message, {}));
                }
            }else {
                let filter = {status:'Approved'};
                if(opt.isUserBased)
                    filter['uploadedUser'] = req.user.user_id;
                req.result = await model.find(filter).sort({_id:-1}).exec();
            }
            next();
        }catch (e) {
            res.status(status.OK).send(response(false, e.message, {}));

        }
    }
}