
const routes = Object.freeze({

    //user related
    SIGN_UP: "/nest/register",
    LOGIN: "/nest/login",
    GET_PROFILE: "/nest/userProfile",
    UPDATE_PROFILE: "/nest/updateProfile",
    INDIVIDUAL_USER:"/nest/individualUser",
    ADD_TO_FAVOURITES:"/nest/favourites",
    DELETE_USER:"/nest/deleteUser",
    VERIFY_USER_DATA: "/nest/verifyUserData",
    INVITE:"/nest/invite",
    GET_ALL_USER:"/nest/getAllUser",

    // items related
    ADD_ITEMS: "/nest/addItems",
    LIST_ITEMS:"/nest/listItems",
    APPROVED_ITEMS:"/nest/approvedItems",
    CATEGORY_WISE_LIST:"/nest/categoryWiseList",
    DELETE_ITEMS:"/nest/deleteItems",
    PURCHASED_ITEMS:"/nest/purchasedItems",
    ITEM_APPROVAL:"/itemApproval",
    INDIVIDUAL_ITEM:"/nest/individualItems",
    SEARCH_ITEM:"/nest/searchItems",
    FILTER:"/nest/filter",
    FILTER_LIST:"/nest/filterBy",
    ITEM_ABUSE:"/nest/reportAbuse",
    ADMIN_SEARCH_FILTER:"/nest/adminSearchFilters",
    TOTAL_PURCHASED_GRID_PER_ITEM:"/nest/totalPurchaseGridPerItem",
    ITEM_RENEWAL:"/nest/itemRenewal",
    GET_RESELL_ELIGIBLE_ITEM:"/nest/renewable",
    IMAGE_APPEND:"/nest/imageAppend",

    // Grid related
    ITEM_GRID:"/nest/itemGridDetails",
    ADD_GRID:"/nest/addGrid",
    UPDATE_GRID:"/nest/updateGrid",
    
    // category related
    ADD_CATEGORY: "/nest/addCategory",
    LIST_CATEGORY: "/nest/listCategory",
    EDIT_CATEGORY: "/nest/editCategory",
    DELETE_CATEGORY: "/nest/deleteCategory",
    
    // coupon code related
    ADD_COUPON: "/nest/addCoupon",
    LIST_COUPON: "/nest/listCoupon",
    EDIT_COUPON: "/nest/editCoupon",
    DELETE_COUPON: "/nest/deleteCoupon",
    VALIDATE_COUPON: "/nest/validateCoupon",

    // user password related
    FORGET_PASSWORD:"/nest/forgetPassword",
    VERIFY_PASSWORD:"/nest/verifyPassword",
    NEW_PASSWORD:"/nest/newPassword",
    CHANGE_PASSWORD:"/nest/changePassword",

    // Admin module report abuse
    LIST_ABUSE:"/nest/listAbuse",
    STATUS_ABUSE:"/nest/statusAbuse",
    DELETE_ABUSE:"/nest/deleteAbuse",
    
    // Wallet
    WALLET_TRANSACTION : "/nest/walletTransaction",
    GET_WALLET_TRANSACTION : "/nest/getUserWalletTransaction",
    GET_USER_WALLET_AMOUNT:"/nest/userWalletAmount",
    GET_INDIVIDUAL_USER_TRANSACTION: "/nest/individualWalletDetails",
    GET_WITHDRAWAL_REQUEST: "/nest/withdrawRequest",
    UPDATE_WITHDRAWAL_REQUEST: "/nest/updateWithdraw",
    DELETE_WITHDRAWAL_REQUEST: "/nest/deleteWithdraw",

    //Commission details
    GET_COMMISSION_DETAILS: "/nest/getCommissionDetails",

    // Payment
    PAYMENT_INTENT:"/nest/paymentIntent",
    UPDATE_PAYMENT: "/nest/updatePayment",
    REFUND_TO_USER: "/nest/refundToUser",

    // transaction
    USER_TRANSACTION: "/nest/userTransaction",
    ITEM_TRANSACTION: "/nest/itemTransaction",

    // Stripe
    GET_PUBLISH_KEY: "/nest/publishKey",

    // Resell
    ITEM_RESELL: "/nest/itemResell",
    ALLOW_RESELL: "/nest/allowResell",

    // commission
    CREATE_NEST_COMMISSION: "/nest/createCommission",
    UPDATE_NEST_COMMISSION: "/nest/updateCommission",
    DELETE_NEST_COMMISSION: "/nest/deleteCommission",
    GET_NEST_COMMISSION:"/nest/getCommission"

});

module.exports = routes;
