/*Filter items based on popularity, new items, more number of units available, favourites, lower metric price*/

module.exports.filters = Object.freeze({
    POPULAR_ITEMS: "Popular items",
    MORE_NO_OF_UNITS:"More no of units",
    NEW_ITEMS: "New items",
    FAVOURITES: "Favourites",
    LOWER_METRIC_PRICE: "Lower metric price"
})
