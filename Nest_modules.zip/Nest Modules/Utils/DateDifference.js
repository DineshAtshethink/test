const moment = require("moment");

module.exports.checkDateDifference = (itemDate) => {
    let itemUploadedDate = [], today = [], i = 0, j = 0;


    new Date(itemDate).toLocaleDateString().split('/').forEach((value) => {
        itemUploadedDate[i] = Number(value);
        i++;
    });

    new Date().toLocaleDateString().split('/').forEach((value) => {
        today[j] = Number(value);
        j++;
    })

     console.table({itemUploadedDate, today});
	const days =  moment([today[2], today[0] - 1, today[1]]).diff(moment([itemUploadedDate[2], itemUploadedDate[0] - 1, itemUploadedDate[1]]), 'days');
	console.table({days:days});
	return days;
};
