const sgMail = require("@sendgrid/mail");
const { baseTemplate } = require("./MailTemplate");

sgMail.setApiKey(process.env.SENDGRID_API_KEY);

module.exports.email = function email(to, subject, username, message) {
console.log('Inside email service');
console.log(to+", "+subject+", "+username+", "+message);
const msg = {
    to,
    from: {
      name: "Nest Market",
      email: "nestmarket.email@gmail.com",
    },
    subject,
    html: baseTemplate(username, message),
  };

  sgMail
    .send(msg)
    .then((response) => {
      console.log("Email sent");
    })
    .catch((error) => {
      console.error(error);
    });
};
