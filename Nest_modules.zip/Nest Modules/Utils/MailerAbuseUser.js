;const nodemailer = require('nodemailer');

module.exports.mailAbuseUser = async (receiver, username, title,comment, date) => {
    try {

        let outputMail = `
        <div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
  <div style="margin:50px auto;width:70%;padṇ">
      <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Nest Market</a>
    </div>
    <p style="font-size:1.1em">Hi ${username},</p>
    <p>Thanks for your report on the product 
    <b style="background: #000;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">${title}</b>
    . Your suggestion is being reviewed. Thanks for sharing with us</p>
    <p style="font-size:0.9em;">Regards,<br />Nest Market</p>
    <hr style="border:none;border-top:1px solid #eee" />
    <div style="float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300">
    </div>
  </div>
</div>
    `
        let outputMail1 = `
        <div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
  <div style="margin:50px auto;width:70%;padṇ">
      <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Nest Market</a>
    </div>
    
    <p>One of the items is reported as abuse. reported user and item details are mentioned below</p>
    <table border="1" cellpadding="2" cellspacing="2" width="100%">
    <thead>
        <tr align="center" valign="middle">
        <th>username</th>
        <th>email Id</th>
        <th>item</th>
        <th>comments</th>
        <th>date & time</th>
    </tr>
    <tr align="center" valign="middle">
    <td align="center" valign="middle">${username}</td>
    <td align="center" valign="middle">${receiver}</td>
    <td align="center" valign="middle">${title}</td>
    <td align="center" valign="middle">${comment}</td>
    <td align="center" valign="middle">${date}</td>
</tr>
    </thead>
    <tbody>
</tbody>
</table>
    <hr style="border:none;border-top:1px solid #eee" /> <p style="font-size:0.9em;">Regards,<br />Nest Market</p>
    
    <div style="float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300">
    </div>
  </div>
</div>
        `

        let transporter = nodemailer.createTransport({
            service: "gmail",
            auth: {
                user: process.env.EMAILID,
                pass: process.env.PASS,
            }
        });

        let info = await transporter.sendMail({
            from: '"NestMarket" nestmarketotpmail@gmail.com',
            to: receiver,
            subject: "Reported Abuse Reg:",
            html: outputMail,
        });

        let adminInfo = await transporter.sendMail({
            from: '"NestMarket" nestmarketotpmail@gmail.com',
            to: "nestmarketotpmail@gmail.com",
            subject: "Reported Abuse Reg:",
            html: outputMail1,
        })

        console.log("Message sent: %s", info.messageId);
        console.log("Message sent %s", adminInfo.messageId);

    } catch (e) {
        console.error(e);
    }
}
