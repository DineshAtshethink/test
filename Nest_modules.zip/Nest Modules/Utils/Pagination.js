const status = require('../Utils/NestHTTPStatusCodes');
const {response} = require('../Utils/Response');
const {filters} = require('../Utils/Filters');
const User = require('../Model/UserSchema');
const moment = require("moment");

module.exports.paginate = (model,option,filter) =>{
    return async(req,res,next)=>{
        const Regex = new RegExp('All','i');
        try {
            if (!Regex.test(req.query.id) && req.query.isFilterExist === 'false') {
                let reqPage = req.query.page;
                let reqLimit = req.query.limit;
                const page = reqPage === undefined ? 1 : parseInt(reqPage);
                const limit = reqLimit === undefined ? 500 : parseInt(reqLimit);

                try {
                    const startIdx = (page - 1) * limit;
                    const endIdx = page * limit;

                    let opt;
                    opt = Object.assign({},option);
                    if(filter)
                    {
                        opt = Object.assign(opt,req.filter);
                    }
                    console.log(opt);
                    req.result = await model.find(opt).limit(endIdx).skip(startIdx).exec();

                } catch (e) {
                    res.status(status.OK).send(response(false, e.message, {}));
                }
            } else if(req.query.isFilterExist === 'true'){
                let {filter} = req.query;
                let option  = req.filter;

                let result;
                switch (filter) {
                    case filters.POPULAR_ITEMS: {
                        result = await model.find(option).sort({'events.clickedCount':-1}).exec();
                        break;
                    }
                    case filters.MORE_NO_OF_UNITS:{
                        result = await model.find(option).sort({unitsForSale:-1}).exec();
                        break;
                    }
                    case filters.NEW_ITEMS: {
                        option['uploadedAt'] = {$gte: new Date(moment().subtract(7, 'days').calendar())};
                        result =  await model.find(option).sort({uploadedAt: -1}).exec();
                        break;
                    }
                    case filters.FAVOURITES: {
                        const user = await User.findOne({_id:req.user.user_id}).exec();
                        let favouritesArray = user.favourites, favouriteitems = [];
                        if(favouritesArray != null && favouritesArray.length > 0 ) {
                            for (const item of favouritesArray) {
                                option['_id'] = item;
                                let filteredItem = await model.findOne(option).exec();
                                if(filteredItem)
                                    favouriteitems.push(filteredItem);
                            }
                        }
                        result = favouriteitems;
                        break;
                    }
                    case filters.LOWER_METRIC_PRICE: {
                        result = await model.find(option).sort({ pricePerUnit: 1}).exec();
                        break;
                    }
                }
                req.result = result;
            }else {
                req.result = await model.find({status:'Approved'}).exec();
            }
            next();
        }catch (e) {
            res.status(status.OK).send(response(false, e.message, {}));

        }
    }
}