const fs = require('fs');
const SHA256 = require('crypto-js/sha256');

module.exports = function(base64Image){
    try{
        let dir = "./NestImages/";
        let imageBuffer = Buffer.from(base64Image, 'base64');
        let fileName = "Tmp_file-" + new Date().getMilliseconds() + ".png";
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir);
        }
        let path = dir + SHA256(fileName + Date.now()) + ".png";
        fs.writeFile(path, imageBuffer, (err) => {
            if (!err)
                console.log("file was created successfully");
        });
        fs.writeFileSync(path, imageBuffer, 'utf8');
        return path;
    }catch (e) {
        console.error(e.message);
    }
}