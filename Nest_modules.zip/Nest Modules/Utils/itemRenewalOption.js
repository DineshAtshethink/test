module.exports.renewal = Object.freeze({
    NEW: "new",
    RENEW: "renew"
});


