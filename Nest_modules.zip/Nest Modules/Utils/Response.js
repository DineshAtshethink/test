module.exports.response = (status, message,body)=>{
    return  {
        status: status,
        message: message,
        body:body
    }
}