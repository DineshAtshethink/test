const Grid = require('../Model/ImageGridSchema');
const {models} = require("mongoose");

class ResellValidator{
    async resellGrids(itemId, smartkeys, userId){
        let filter = {itemId: itemId, smartKey:{$in: smartkeys}, isActive: true, paymentStatus: 'Paid'}
        if(userId)
            filter.purchaseUserId = userId;
        await Grid.find(filter, (err, grid) => {
            if (err) {
                console.log(err);
            } else {
                let resultKeys = [];
                if (grid.length > 0) {
                    smartkeys.forEach(element => {
                        let resellGrid = grid.filter(x => x.resellGridDetails.some(data => data.key === element && !data.isSold));
                        if (resellGrid && resellGrid.length > 0) {
                            resultKeys.push(element);
                        }
                    });
                }
                return resultKeys;
            }
        });
    }
}

module.exports = ResellValidator;