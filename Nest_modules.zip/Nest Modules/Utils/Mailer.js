const nodemailer = require('nodemailer');

module.exports.mail = async(receiver, username, otp)=> {
    try {

        let outputMail = `
        <div style="font-family: Helvetica,Arial,sans-serif;min-width:1000px;overflow:auto;line-height:2">
  <div style="margin:50px auto;width:70%;padṇ">
      <a href="" style="font-size:1.4em;color: #00466a;text-decoration:none;font-weight:600">Nest Market</a>
    </div>
    <p style="font-size:1.1em">Hi,${username}</p>
    <p>OTP for changing the password.OTP is valid for 60 Seconds</p>
    <h2 style="background: #000;margin: 0 auto;width: max-content;padding: 0 10px;color: #fff;border-radius: 4px;">${otp}</h2>
    <p style="font-size:0.9em;">Regards,<br />Nest Market</p>
    <hr style="border:none;border-top:1px solid #eee" />
    <div style="float:right;padding:8px 0;color:#aaa;font-size:0.8em;line-height:1;font-weight:300">
    </div>
  </div>
</div>
        `

        let transporter = nodemailer.createTransport({
            service:"gmail",
            auth: {
                user: process.env.EMAILID,
                pass: process.env.PASS,
            }
        });

        let info = await transporter.sendMail({
            from: '"NestMarket" nestmarketotpmail@gmail.com',
            to: receiver,
            subject: "OTP Verification",
            html: outputMail,
        });

        console.log("Message sent: %s", info.messageId);

    }catch (e) {
        console.error(e);
    }
}
