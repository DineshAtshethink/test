module.exports.baseTemplate = function baseTemplate(user, message) {
  return `
<div style="background:#ECECEC; padding:30px;font-family: 'Roboto Slab', serif;"
     >
  <div style="height: 100px; padding: 10px;
              display:flex; align-items:center; justify-content:center;
" >
    <img src="http://3.109.203.18:3030/static/logo.png" width=100 height=100
         alt="nest image">
  </div>
  <div style="background:#FFF;border-radius:10px 10px; padding: 5px;
              ">
               Hi ${user},  
               <br> 
               ${message}
                <br>
              
               Thanks&Regards,<br>
               NestMarket
              </div>
  <div style="background:#EFEFEF;height: 10px;
              padding:10px;
              border-radius:0 0 10px 10px">
    Copyrights©2022 by NestMarket
  </div>
</div>

`;
};
