
module.exports = Object.freeze({
    REFUND: 'Refund',
    PURCHASE: 'Purchase',
    REDEEM : 'Redeem'
});