require('dotenv').config();
const express = require('express');
const routes = require('../Utils/NestRoutes');
const status = require('../Utils/NestHTTPStatusCodes');
const {Item} = require('../Model/ItemSchema');
const {response} = require('../Utils/Response');
const route = require("../Utils/NestRoutes");
const Category = require("../Model/CategorySchema");
const {paginate2} = require("../Utils/PaginateTwo");
const User = require('../Model/UserSchema');
const moment = require("moment");
const NestLog = require('../Logger/NestLog');
const {logBody} = require('../Logger/LogBody');
const logger = new NestLog().logger;
const {Abuse} = require('../Model/AbuseSchema');
const {email} = require("../Utils/sendGridMailer.js");
const router = express.Router();

router.post(routes.LIST_ABUSE, paginate2(Abuse, {"status": {$in: ["new", "In-progress", "closed"]}}), async (req, res) => {
    logger.info(logBody(req, 'Inside Admin list abuse page'));
    let finalResponse;
    try {
        let abuses = req.result;
        let finalResult = [];
        if (abuses && abuses.length > 0) {
            for (const abuse of abuses) {
                let user = await User.findById(abuse['reportedUser']).exec();
                let abuseObject = abuse.toObject();
                if (user) {
                    abuseObject['firstName'] = user.firstName;
                    abuseObject['lastName'] = user.lastName;
                    abuseObject['Email'] = user.emailID;
                    abuseObject['Age'] = user.age;
                    abuseObject['createdAt'] = user.createdAt;
                    abuseObject['userStatus'] = user.status;
                    finalResult.push(abuseObject);
                }
            }
            logger.info(logBody(req, 'AllOk Admin list abuse page'));
            finalResponse = response(true, "success", finalResult);
        } else {
            logger.error(logBody(req, 'Sometime went wrong. items query is null'));
            finalResponse = response(false, "Sometime went wrong", []);
        }
    } catch (e) {
        logger.error(logBody(req, 'error occured while getting abuse items', e.message));
        finalResponse = response(false, e.message, {});
    }
    res.status(status.OK).send(finalResponse);
});

router.delete(route.DELETE_ABUSE, async (req, res) => {
    logger.info(logBody(req, 'Inside Admin delete abuse page'));
    let finalResponse;
    try {
        let abuseId = req.query.abuseId;
        if (abuseId) {
            logger.info(logBody(req, 'abuseId is present'));
            let result = await Abuse.findOneAndDelete({_id: req.query.abuseId}).exec();
            if (result) {
                logger.info(logBody(req, 'AllOk Admin delete abuse page'));
                finalResponse = response(true, 'success', result);
            } else {
                logger.error(logBody(req, 'Sometime went wrong. items query is null'));
                finalResponse = response(false, 'No abuse data found', result);
            }
        } else {
            logger.error(logBody(req, 'abuseId is not present'));
            finalResponse = response(false, 'Invalid abuseId', {});
        }
    } catch (e) {
        logger.error(logBody(req, 'error occured while deleting abuse items', e.message));
        finalResponse = response(false, 'something wrong while deleting abuse data', e.message);
    }
    res.json(finalResponse);
});

router.put(routes.STATUS_ABUSE, async (req, res) => {
    logger.info(logBody(req, 'Inside Admin chagne status abuse page'));
    let finalResult;
	console.log("status:"+req.body.status)
    try {
        const filter = {_id: req.body['abuseId']};
        const update = {status: req.body["status"]};
        await Abuse.findOneAndUpdate(filter, update, {new: true})
            .then(result => {
                logger.info(logBody(req, 'AllOk Admin chagne status abuse page'));

                 email(
                      'nestadmin@gmail.com',
                       'Abuse status change',
                        'Nest Market Admin',
                       `<br> Abuse status has been changed to ${result.status} for userID: ${result.reportedUser}`
                   )
		    finalResult = response(true, "success", result);
            })
            .catch(e => {
                logger.error(logBody(req, 'Sometime went wrong items status change'));
                finalResult = response(false, "Sometime went wrong", e.message);
            });
    } catch (err) {
        logger.error(logBody(req, 'Sometime went wrong items status change'));
        finalResult = response(false, "Sometime went wrong", err.message);
    }
    res.status(status.OK).send(finalResult);
});

module.exports = router;
