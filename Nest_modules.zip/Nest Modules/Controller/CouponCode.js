const express = require('express');
const CouponCode = require('../Model/CouponCodeSchema');
const mongoose = require('mongoose');
const status = require("../Utils/NestHTTPStatusCodes");
const route = require("../Utils/NestRoutes");
const {response} = require("../Utils/Response");
const router = express.Router();
const NestLog = require('../Logger/NestLog');
const {logBody} = require('../Logger/LogBody');
const logger = new NestLog().logger;
const {checkDateDifference} = require('../Utils/DateDifference');


router.post(route.ADD_COUPON, async (req, res) => {
    logger.info(logBody(req, 'Inside Admin Add coupon'));
    const request = req.body;
    const coupon = await new CouponCode({
        name: request.name,
        displayName: request.displayName ? request.displayName.toUpperCase() : request.name.toUpperCase(),
        type: request.type,
        couponValue: request.couponValue,
        fromDate: request.fromDate,
        toDate: request.toDate,
        status: request.status ? request.status : "Inactive"
    });

    await coupon.save().then(result => {
        logger.info(logBody(req, 'AllOk Inside Admin Add coupon'));
        let finalResult = response("success", true, result);
        res.status(status.CREATED).send(finalResult);
    }).catch(e => {
        // console.log(e);
        logger.error(logBody(req, 'Error Occurred Unable to create CouponCode', e.message));
        let finalResult = response(false, "Unable to create CouponCode", e.message);
        res.status(status.BAD_REQUEST).send(finalResult)
    });
});


router.post(route.LIST_COUPON, async (req, res) => {
    logger.info(logBody(req, 'Inside Admin List coupon'));
    let finalResult, statusCode;
    const request = req.body;
    try {
        let coupon = {};
        if (request.status && request.status !== "all") {
            coupon = await CouponCode.find({status: request.status}).exec();
        } else {
            coupon = await CouponCode.find().exec();
        }
        logger.info(logBody(req, 'AllOk Inside Admin List coupon'));
        statusCode = status.OK;
        finalResult = response(true, "success", coupon);
    } catch (e) {
        statusCode = status.BAD_REQUEST;
        logger.error(logBody(req, 'Error Occurred Unable to list CouponCode', e.message));
        finalResult = response(false, "Error Occurred Please Check Mandatory Fields!", e.message);
    }
    res.status(statusCode).send(finalResult);
});

router.put(route.EDIT_COUPON, async (req, res) => {
    logger.info(logBody(req, 'Inside Admin Edit coupon'));
    let request = req.body, finalResult, statusCode;
    const filters = {_id: request.id};
    const update = {
        name: request.name,
        displayName: request.displayName,
        type: request.type,
        couponValue: request.couponValue,
        fromDate: request.fromDate,
        toDate: request.toDate,
        status: request.status,
        updatedAt: Date.now()
    };
    await CouponCode.findOneAndUpdate(filters, update, {new: true})
        .then(result => {
            logger.info(logBody(req, 'AllOk Inside Admin Edit coupon'));
            finalResult = response(true, "success", result);
            statusCode = status.OK;
        }).catch(e => {
            logger.error(logBody(req, 'Error Occurred Unable to Edit CouponCode', e.message));
            finalResult = response(false, "Error Occurred Please Check Mandatory Fields", e.message);
            statusCode = status.BAD_REQUEST;
        });
    res.status(statusCode).send(finalResult);
});

router.delete(route.DELETE_COUPON, async (req, res) => {
    logger.info(logBody(req, 'Inside Admin Delete coupon'));
    let request = req.body, finalResult, statusCode;
    try {
        const name = request.name;
        const Coupon = await CouponCode.findOne({name: name}).exec();
        Coupon != null ? await CouponCode.deleteOne({name: name}) : null;
        statusCode = status.OK;
        finalResult = response(true, "Removed Successfully", "");
        logger.info(logBody(req, 'AllOk Inside Admin Delete coupon'));
    } catch (e) {
        statusCode = status.BAD_REQUEST;
        logger.error(logBody(req, 'Error Occurred Unable to Delete CouponCode', e.message));
        finalResult = response(false, "Error Occurred Please Check Mandatory Fields!", e.message);
    }
    res.status(statusCode).send(finalResult);
});

router.post(route.VALIDATE_COUPON, async (req, res) => {
    logger.info(logBody(req, 'Inside validate coupon'));
    let finalResponse, statusCode;
    const request = req.body;
    try {

        let query = {
            status: "Active",
            displayName: request.displayName,
        }

        let coupon = await CouponCode.findOne(query).exec();
        if (coupon) {
            if (checkDateDifference(coupon.toDate) < 0) {
                finalResponse = response(true, 'success', coupon);
            } else {
                finalResponse = response(false, 'coupon code date is expired');
            }
        } else {
            finalResponse = response(false, 'Invalid coupon');
        }

    } catch (e) {
        logger.error(logBody(req, 'Error Occurred Unable to validate CouponCode', e.message));
        finalResponse = response(false, "Error Occurred Please Check Mandatory Fields!", e.message);
    }
    res.json(finalResponse);
});

module.exports = router;