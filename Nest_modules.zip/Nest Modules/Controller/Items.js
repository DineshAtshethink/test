require('dotenv').config();
const express = require('express');
const routes = require('../Utils/NestRoutes');
const status = require('../Utils/NestHTTPStatusCodes');
const {Item} = require('../Model/ItemSchema');
const uploadImage = require('../Utils/ImageUpload');
const {response} = require('../Utils/Response');
const route = require("../Utils/NestRoutes");
const Category = require("../Model/CategorySchema");
const {paginate} = require("../Utils/Pagination");
const {paginate2} = require("../Utils/PaginateTwo");
const {filters} = require('../Utils/Filters');
const User = require('../Model/UserSchema');
const moment = require("moment");
const {checkDateDifference} = require('../Utils/DateDifference');
const {mailAbuseUser} = require('../Utils/MailerAbuseUser');
const Grid = require('../Model/ImageGridSchema');
const {Abuse} = require('../Model/AbuseSchema');
const {renewal} = require('../Utils/itemRenewalOption');
const {Wallet} = require("../Model/WalletSchema");
const NestLog = require('../Logger/NestLog');
const {logBody} = require('../Logger/LogBody');
const {email} = require("../Utils/sendGridMailer.js");
const logger = new NestLog().logger;
const ImageDetails = require('../Utils/ImageDetails');
const imageAppender = require('../Utils/ImageAppender');
const EditImageVersion = require('../Model/EditImageVersion')

const router = express.Router();


/**
 * @BodyParam title string required
 * @BodyParam description string required
 * @BodyParam categoryId string required
 * @BodyParam price number required
 * @BodyParam itemCondition string required
 *
 * @Description This route is used to create new item
 *
 * @returns {object}
 *
 * */

router.post(routes.ADD_ITEMS, [getCategoryid, uploadImage], async (req, res) => {
    logger.info(logBody(req, 'Inside add items'));
    let finalResponse;
    try {
        logger.info(logBody(req, 'Processing input item data'));
        let request = req.body;
        const item = await new Item({
            uploadedUser: req.user.user_id,
            productImage: req['NestFilePath'],
            originalImagePath: req['originalPath'],
            title: request.title.replace(/[^a-zA-Z ]/g, ""),
            price: request.price,
            unitsForSale: req['imageData'].totalUnits,
            pricePerUnit: req.imageData.levels === 1 ? req.imageData.level1.pricePerUnit : req.imageData.level2.pricePerUnit,
            gridLevels: request.gridLevels,
            category: {
                id: req['category_id'],
                name: request['category_name'],
                description: request['category_description']
            },
            condition: {
                name: request['condition_name'],
                description: request['condition_description']
            },
            imageData: req['imageData'],
            timePeriod: request.timePeriod,
            createdAt: Date.now(),
            updatedAt: Date.now(),
            description: request.description,
            productLink: req.protocol + "://" + req.get('host') + req['NestFilePath']
        });

        await item.save()
            .then((result) => {
                logger.info(logBody(req, 'New item is added successfully', result['_id']));
                finalResponse = response(true, "success", result);
            })
            .catch(err => {
                logger.error(logBody(req, 'error occured while saving new item', err.message));
                finalResponse = response(false, err.message, {});
            });
    } catch (err) {
        logger.error(logBody(req, 'something wrong while processing add new item', err.message));
        finalResponse = response(false, err.message, {});
    }
    res.json(finalResponse);
});

/**
 * @Description: Middleware which find category id
 * */

async function getCategoryid(req, res, next) {
    logger.info(logBody(req, 'Inside category validation'));
    try {
        let category = await Category.findOne({title: req.body.category_name, status: 'Active'}).exec();
        if (await category != null) {
            logger.info(logBody(req, 'category validation - success'));
            req['category_id'] = await category._id;
            next();
        } else {
            logger.error(logBody(req, 'Invalid category'))
            res.send(response(false, 'Invalid category name'));
        }
    } catch (e) {
        logger.error(logBody(req, 'Something wrong while validating category name', e.messag))
        res.json(response(false, 'Something wrong while validating category name', e.message));
    }
}

router.get(route.FILTER_LIST, (req, res) => {
    let finalresponse, finalresult = [];
    try {
        Object.values(filters).forEach(value => {
            let x = {};
            x['filterTitle'] = value;
            finalresult.push(x);
        })
        finalresponse = response(true, 'success', finalresult);
    } catch (e) {
        finalresponse = response(false, 'something wrong with filter array', e.message);
    }
    res.json(finalresponse);
});

router.get(route.FILTER, async (req, res) => {
    let {filter, categoryId} = req.query;
    let result, finalResult, option = {};
    if (categoryId !== undefined) option['category.id'] = categoryId;
    console.log(option);

    try {
        switch (filter) {
            case filters.POPULAR_ITEMS: {
                result = await Item.find(option).sort({'events.clickedCount': -1}).exec();
                break;
            }
            case filters.MORE_NO_OF_UNITS: {
                result = await Item.find(option).sort({unitsForSale: -1}).exec();
                break;
            }
            case filters.NEW_ITEMS: {
                option['uploadedAt'] = {$gte: new Date(moment().subtract(7, 'days').calendar())};
                console.log(option)
                result = await Item.find(option).sort({uploadedAt: -1}).exec();
                break;
            }
            case filters.FAVOURITES: {
                const user = await User.findOne({_id: req.user.user_id}).exec();
                let favouritesArray = user.favourites, favouriteitems = [];
                if (favouritesArray != null && favouritesArray.length > 0) {
                    for (const item of favouritesArray) {
                        option['_id'] = item;
                        let filteredItem = await Item.findOne(option).exec();
                        favouriteitems.push(filteredItem);
                    }
                }
                result = favouriteitems;
                break;
            }
            case filters.LOWER_METRIC_PRICE: {
                result = await Item.find(option).sort({pricePerUnit: 1}).exec();
                break;
            }
        }
        finalResult = response(true, 'success', result);
    } catch (e) {
        console.log(result);
        finalResult = response(true, 'No item found', result);
    }
    console.log(finalResult);
    res.jsonp(finalResult);
});

/**
 * @Description : it helps to generate smartKey using grids input
 *
 * @param grids
 * @param smartKeyArray
 * @param property
 *
 * @returns smartKey
 * */
function smartKeyGenerator(grids, smartKeyArray, property) {
    grids.forEach(grid => {
        smartKeyArray = smartKeyArray.concat(grid[property]);
    });
    let x = new Set();
    smartKeyArray.forEach(smartKey => {
        x.add(smartKey);
    });
    return [...x];
}


/**
 * @BodyParam itemId is required
 * @BodyParam event
 * @BodyParam isIndividualPurchase
 *
 * @return {object}
 *
 * @description: it helps to add event to item and give individual item details
 *
 * steps:
 * 1. check whether event is triggered or not
 * 2. check whether it is individual purchase or not
 * 3. if it is individual purchase then add individual purchase units in smartkey
 * 4. if it is not individual purchase then add all purchased units in smartkey
 * 5. check whether resell is allowed or not
 * 6. if resell is not allowed, no need to provide resell keys
 * 7. if resell is allowed, need to provide resell keys
 * 8. finally, provide whole smartkey, resellkey, item details, resell details, resell units, resell price, totalunits, isNew, isFavorite
 * */
router.post(routes.INDIVIDUAL_ITEM, async (req, res) => {
    logger.info(logBody(req, 'Inside Individual item'));
    let finalResponse;
    try {
        let {itemId, event, isIndividualPurchase} = req.body;
        let item = {};
        if (event) {
            logger.info(logBody(req, 'item event triggered, incrementing the count'));
            item = await Item.findByIdAndUpdate(itemId, {$inc: {'events.clickedCount': 1}}).exec();
        }

        let fetchedItem = await Item.findById({_id: itemId}).exec();

        let filter = {
            paymentStatus: 'Paid',
            itemId: itemId,
            isActive: true
        };

        if (isIndividualPurchase) {
            filter['purchaseUserId'] = req.user.user_id;
        }

        let grids = await Grid.find(filter).select({'smartKey': 1, 'resellGridDetails': 1}).exec();
        let joinedKeys = [];

        if (fetchedItem) {
            item = fetchedItem.toObject();
            let smartKeyArray = [];

            item['smartKey'] = smartKeyGenerator(grids, smartKeyArray, 'smartKey');

            if (item.isResellAllowed) {
                grids.forEach(grid => {
                    grid.resellGridDetails.forEach(data => {
                        try {
                            if (!data.isSold && !isIndividualPurchase) {
                                item['smartKey'] = calibrateKeys(joinedKeys, item, data);
                            }

                            if (isIndividualPurchase && data.isSold) {
                                item['smartKey'] = calibrateKeys(joinedKeys, item, data);
                            }

                        } catch (e) {
                            logger.error(logBody(req, 'error in resell grid details', e.message));
                        }
                    });
                    if (isIndividualPurchase) {
                        let resellFilterData = grid.resellGridDetails.filter(data => !data.isSold).map(data => data.key);
                        grid.smartKey.forEach(key => {
                            if (resellFilterData.includes(key)) {
                                let index = item['smartKey'].indexOf(key);
                                if (index > -1) {
                                    item['smartKey'].splice(index, 1);
                                }
                            }
                        })
                    }
                });


                console.log(`item.smartKey.length - ${item.smartKey.length}`);
                item['purchaseUnitsCount'] = item.smartKey.length;
                //unsold units
                // let unsoldkeys = await getUnsoldGridItems(item);
                item['resellKeys'] = joinedKeys;
                /*item['unsoldGrids'] = unsoldkeys;
                item['unsoldCount'] = unsoldkeys.length;*/

            }
        }

        // console.log(item);
        // console.log("isExpired : "+checkDateDifference(item.uploadedAt) <=  item.timePeriod, +", timePeriod : "+item['timePeriod']);
        // if (checkDateDifference(item.uploadedAt) <= item.timePeriod) {
        let result = item;
        let currentUser = await User.findById(req.user.user_id).exec();
        if (currentUser) {
            result['isFavourite'] = currentUser['favourites'].includes(item['_id']);
            result['isProductNew'] = checkDateDifference(item['uploadedAt']) <= 7; //current date and  item date difference should be less than 7 days
            result['totalNumberOfUnits'] = Math.abs(item['smartKey'].length - item['unitsForSale']);
        }

        finalResponse = response(true, "success", result);
        // } else
        //     finalResponse = response(true, 'item not found');
    } catch (err) {
        console.log(err.message)
        finalResponse = response(false, err.message);
    }
    res.json(finalResponse);
});


function calibrateKeys(joinedKeys, item, data) {
    joinedKeys.push({key: data.key, price: data.price});
    let index = item['smartKey'].indexOf(data.key);
    if (index > -1) {
        item['smartKey'].splice(index, 1);
    }
    return item['smartKey']
}

async function getUnsoldGridItems(item) {
    console.log('Inside unsold grid items');
    let purchasedGrids = item['smartKey'];
    let soldArray = [], unsoldArray = [], traceArray = [];

    purchasedGrids.forEach(key => {
        let [, , trace, , target] = key.split('_');
        let newTarget = getNumberArray(target);
        soldArray.push(newTarget);
        let newTrace = getNumberArray(trace);
        traceArray.push(newTrace);
    });

    let {levels, level1, level2} = item['imageData'];
    let {rows, columns} = levels === 1 ? level1 : level2;
    let keys = [];
    unsoldArray = checkUnsoldItems(rows, columns, soldArray, traceArray);
    unsoldArray.forEach(coord => {
        keys.push(item._id + "_trace_" + coord[0] + "_target_" + coord[1]);
    })

    return keys;
}

function getNumberArray(arr) {
    return arr.split(',').map(i => Number(i));
}

function checkUnsoldItems(rEnd, cEnd, soldArray, traceArray) {

    let result = [];
    if (arrayAlreadyHasArray(traceArray, [-1, -1])) {
        result = looper(-1, -1, rEnd, cEnd, soldArray, traceArray);
    } else {
        for (let r1 = 0; r1 < rEnd; r1++) {
            for (let c1 = 0; c1 < cEnd; c1++) {
                let arr = looper(r1, c1, rEnd, cEnd, soldArray, traceArray);
                if (arr.length > 0)
                    result = result.concat(arr);
            }
        }
    }
    return result;
}

function looper(r1, c1, rEnd, cEnd, soldArray, traceArray) {
    let unsoldArray = [];
    for (let r2 = 0; r2 < rEnd; r2++) {
        for (let c2 = 0; c2 < cEnd; c2++) {
            let tracer = [r1, c1], coord = [r2, c2];

            if (!arrayAlreadyHasArray(traceArray, tracer) || (arrayAlreadyHasArray(traceArray, tracer) && !arrayAlreadyHasArray(soldArray, coord)))
                unsoldArray.push([tracer.join(','), coord.join(',')]);

        }
    }
    return unsoldArray;
}

function arrayAlreadyHasArray(arr, subarr) {
    for (let i = 0; i < arr.length; i++) {
        let checker = false
        for (let j = 0; j < arr[i].length; j++) {
            if (arr[i][j] === subarr[j]) {
                checker = true
            } else {
                checker = false
                break;
            }
        }
        if (checker) {
            return true
        }
    }
    return false
}

async function resellDataPreprocessing(req, grids) {
    logger.info(logBody(req, "resellDataPreprocessing"));
    let processedGrids = [];
    processedGrids = grids.map(grid => {
        try {
            let result = false;
            let {smartKey, resellGridDetails} = grid;
            if (resellGridDetails.length > 0 && smartKey.length === resellGridDetails.length) {
                logger.info(logBody(req, "resellDataPreprocessing", "resellGridDetails.length > 0 && smartKey.length === resellGridDetails.length - true"));
                result = resellGridDetails.every(resellGrid => resellGrid['isSold'] === true);
            }
            if (result) {
                logger.info(logBody(req, "resellDataPreprocessing", `result - ${result}`));
                grid['isActive'] = false;
            }
        } catch (err) {
            console.log(err.message);
        }
        return grid;
    });

    for (const grid of processedGrids) {
        logger.info(logBody(req, "resellDataPreprocessing", `grid - ${JSON.stringify(grid.resellGridDetails)}`));
        await Grid.findByIdAndUpdate(grid._id, grid, {new: true}).exec();
    }
    logger.info(logBody(req, "resellDataPreprocessing", `processedGrids - ${JSON.stringify(processedGrids.resellGridDetails)}`));
}

/**
 * @BodyParam itemId
 * @BodyParam smartKey
 * @BodyParam updatedPrice
 *
 * @returns {object}
 *
 * steps:
 * 1. check if item is active
 * 2. get related grids of given smartKey
 * 3. And update the price of each grid and update the grid
 * */

router.post(routes.ITEM_RESELL, async (req, res) => {
    let finalResponse;
    let relatedGrids;
    try {
        let {itemId, smartKey, updatedPrice} = req.body, relatedGrids = [];

        if (itemId && updatedPrice && await Item.exists({_id: itemId, isResellAllowed: true})) {
            for (const key of smartKey) {
                await Grid.find({
                    smartKey: {$elemMatch: {$eq: key}},
                    isActive: true
                }).exec()
                    .then(result => {
                        if (result && result.length > 0) {
                            relatedGrids = relatedGrids.concat(result);
                        }
                    }).catch(err => {
                        logger.error(logBody(req, 'error occured while fetching grid data in  item resell', err.message));
                    });
            }
            await resellDataPreprocessing(req, relatedGrids);

            let gridDetailsMap = {}, keys = smartKey;
            if (relatedGrids.length > 0) {
                relatedGrids.forEach(grid => {
                    let purchasedKey = grid['smartKey'];
                    let purchasedkeyMatch = purchasedKey.filter(key => keys.includes(key));
                    let {resellGridDetails} = grid;
                    let oldresellGridDetails = resellGridDetails ? resellGridDetails.length : 0;
                    if (purchasedkeyMatch && resellGridDetails && resellGridDetails.length > 0) {
                        let resellkeyObjects = [], unlockedKeys = [];
                        resellkeyObjects = resellGridDetails.map(resellGrid => resellGrid.key);
                        unlockedKeys = purchasedkeyMatch.filter(resellkeyObject => !resellkeyObjects.includes(resellkeyObject));
                        if (unlockedKeys.length > 0) {
                            unlockedKeys.forEach(unlockedKey => {
                                let resellkeyObject = {
                                    key: unlockedKey,
                                    price: updatedPrice,
                                    isSold: false
                                };
                                resellGridDetails.push(resellkeyObject);
                            });
                        }
                    } else if (purchasedkeyMatch && resellGridDetails.length === 0) {
                        purchasedkeyMatch.forEach(key => {
                            console.log(key);
                            if (key) {
                                let resellkeyObject = {
                                    key: key,
                                    price: updatedPrice,
                                    isSold: false
                                };
                                let previousResellGridDetails = grid.resellGridDetails;
                                previousResellGridDetails.push(resellkeyObject);
                                grid.resellGridDetails.concat(previousResellGridDetails);
                                console.log(grid.resellGridDetails);
                            }
                        });
                    }
                    if (grid.resellGridDetails.length > oldresellGridDetails || oldresellGridDetails === 0) {
                        gridDetailsMap[grid._id] = grid;
                    }
                })

                if (Object.keys(gridDetailsMap).length > 0) {
                    let gridIds = Object.keys(gridDetailsMap);
                    gridIds.forEach(id => {
                        let grid = gridDetailsMap[id];
                        Grid.findByIdAndUpdate(grid._id, grid, {new: true}).exec()
                            .then(result => {
                                if (result) {
                                    logger.info(logBody(req, 'grid updated successfully in item resell', result));
                                }
                            }).catch(err => {
                            logger.error(logBody(req, 'error occured while updating grid data in  item resell', err.message));
                        });
                    });
                    finalResponse = response(true, 'selected units are added to marketplace for resell successfully', {});
                } else {
                    finalResponse = response(true, 'There is no grids to update in resell', {});
                }
            } else {
                finalResponse = response(true, 'selected units are added to marketplace for resell successfully', {});
            }
        }
    } catch (e) {
        finalResponse = response(false, 'something wrong while updating price', e.message);
    }
    res.json(finalResponse);
});

function filteredArray(array, props) {
    console.log(array);
    const filteredArray = array.reduce((acc, current) => {
        let x = array.find(data => data[props] === current[props]);
        if (!x) {
            return acc.concat([current]);
        } else {
            return acc;
        }
    }, []);
    console.log(filteredArray);
    return filteredArray;
}

function filterBasedOnMongoId(array) {
    return array.reduce((acc, current) => {
        let x = array.find(data => data._id.equals(current._id));
        if (!x) {
            return acc.concat([current]);
        } else {
            return acc;
        }
    }, []);
}

router.post(routes.SEARCH_ITEM, async (req, res) => {
    let finalResponse;
    try {
        let searchText = req.body.search;
        let option = req.query.filter;
        let items = [];
        if (option === 'Item for sale') {
            items = await Item.find({
                title: {$regex: searchText, $options: 'i'},
                status: 'Approved',
                'paymentStatus': 'Yet to be Paid'
            }).exec();
        } else if (option === 'Purchased items') {
            let grids = await Grid.find({'purchaseUserId': req.user.user_id, 'paymentStatus': 'Paid'}).exec();
            let itemArray = [];
            for (const grid of grids) {
                let itemResult = await Item.find({
                    _id: grid['itemId'],
                    title: {$regex: searchText, $options: 'i'},
                    status: 'Approved'
                }).exec();
                itemArray.push(itemResult);
            }
            items = itemArray;
        } else if (option === 'Marketplace') {
            items = await Item.find({title: {$regex: searchText, $options: 'i'}, status: 'Approved'}).exec();
        }

        if (items != null && items.length > 0) {
            let filteredSearchReult = [];
            items.forEach(item => {
                if (checkDateDifference(item.uploadedAt) <= item.timePeriod)
                    filteredSearchReult.push(item);
            })
            finalResponse = response(true, 'success', filteredSearchReult);
        } else
            finalResponse = response(true, 'No item found', []);
    } catch (e) {
        finalResponse = response(false, e.message);
    }
    res.status(status.OK).send(finalResponse);
});

router.get(route.PURCHASED_ITEMS, async (req, res) => {
    let finalResponse;
    try {
        let userPurchasedItems = await Grid.find({
            purchaseUserId: req.user.user_id,
            paymentStatus: 'Paid'
        }).exec();

        console.log(userPurchasedItems)

        let newArray = [], removableItem = [];

        for (let {itemId, smartKey, resellGridDetails} of userPurchasedItems) {
            try {
                let index = -1, isResellDone = false;
                if (await Item.exists({_id: itemId, isResellAllowed: true})) {
                    let counter = 0;
                    resellGridDetails.forEach(data => {
                        if (data.isSold) counter += 1;
                    });
                    isResellDone = counter === smartKey.length;
                }

                let isItemIdExist = newArray.some(data => {
                    index++;
                    return data.itemId === itemId
                });
                if (!isResellDone) {
                    isItemIdExist && index > -1 ? newArray[index].smartKey.push(smartkey) : newArray.push({
                        itemId,
                        smartKey
                    });
                }
            } catch (e) {
                console.log(e.message);
            }
        }

        let finalResult = []
        console.log(newArray);
        for (const data of newArray) {
            let item = await Item.findOne({_id: data.itemId}).exec();
            if (item) {
                let itemObject = item.toObject();
                itemObject['smartKey'] = data.smartKey;
                finalResult.push(itemObject);
            }
        }

        if (finalResult.length > 0) {

            finalResponse = response(true, 'success', sortItems(finalResult));
        } else
            finalResponse = response(true, 'No purchased item found', finalResult);

    } catch (err) {
        finalResponse = response(false, err.message);
    }
    res.json(finalResponse);
});

function sortItems(items) {
    items.sort(function (a, b) {
        const item_id_1 = a._id;
        const item_id_2 = b._id;
        if (item_id_1 < item_id_2) {
            return 1;
        }
        if (item_id_1 > item_id_2) {
            return -1;
        }
        return 0;
    });
    return items;
}


router.get(route.GET_RESELL_ELIGIBLE_ITEM, async (req, res) => {
    logger.info(logBody(req, 'Inside get renewable item'));
    let finalResponse;
    try {
        //dev : 20, prod : 90
       	let renewableItem = await Item.find({'percentageSold': {$gte: 5}, 'isResellAllowed': false}).exec();
        if (renewableItem) {
            logger.info(logBody(req, 'renewable item is fetched', renewableItem.length));
            finalResponse = response(true, 'success', renewableItem);
        } else {
            logger.info(logBody(req, 'No renewable item found'));
            finalResponse = response(true, 'No data found', []);
        }
    } catch (e) {
        logger.error(logBody(req, 'something wrong while fetching data', e.message));
        finalResponse = response(false, 'error occured', e.message);
    }
    res.json(finalResponse);
})

router.get(routes.LIST_ITEMS, paginate2(Item, {}), async (req, res) => {
    let finalResponse;
    try {
        let items = req.result;
	    console.log(`items count: ${items.length}`);
        if (items !== null && items.length > 0) {
            let finalListItems = [];
            items.forEach(item => {
 console.log(item.uploadedAt);
		    if (checkDateDifference(item.uploadedAt) <= item.timePeriod)
                    finalListItems.push(item);
            });
            finalResponse = response(true, "success", finalListItems);
        }
    } catch (e) {
        finalResponse = response(false, e.message, {})
    }
    res.status(status.OK).send(finalResponse);
});

/**
 * @QueryParam: categoryid
 *
 * @description: get all items by category id
 *
 * @return: success or error
 *
 * steps
 * 1. get all items by category id and paginate
 * 2. if items found then return success
 * 3. else return error
 * */

router.get(route.CATEGORY_WISE_LIST, [(req, res, next) => {
    if (req.query.id !== 'All') {
        req.filter = {'category.id': req.query.id, status: 'Approved'}
    } else {
        req.filter = {status: 'Approved'}
    }
    next();
}, paginate(Item, {}, true)], async (req, res) => {
    let finalResponse, filteredCategory;

    try {
        let user = await User.findById(req.user.user_id).exec();
        if (req.result) {
            let categoryArray = [];
            req.result.forEach(item => {
                console.log(checkDateDifference(item.uploadedAt) <= item.timePeriod)
                if (checkDateDifference(item.uploadedAt) >= 0 && checkDateDifference(item.uploadedAt) <= item.timePeriod) {
                    filteredCategory = item.toObject();
                    filteredCategory['isProductNew'] = checkDateDifference(item['uploadedAt']) <= 7;
                    filteredCategory['isFavourite'] = user !== null ? user['favourites'].includes(item['_id']) : false;
                    filteredCategory['totalNumberOfUnits'] = Math.ceil(Math.random() * 1000);
                    categoryArray.push(filteredCategory);
                }
            })
            finalResponse = response(true, "success", categoryArray);
        } else
            finalResponse = response(true, 'No item found')

    } catch (e) {
        finalResponse = response(false, e.message, {});
    }
    res.status(status.OK).send(finalResponse);
});

router.get(routes.APPROVED_ITEMS, paginate2(Item, {
    status: {$in: ["Yet to be approved", "Approved"]},
    isUserBased: true
}), async (req, res) => {
    let finalResponse, itemArray = [];
    try {
        let approvedItems;

        let user = await User.findById(req.user.user_id).exec();
        let resultData = req.result || [], gridData, resellGridData;
        let uniqueId = new Set();

        gridData = await Grid.find({purchaseUserId: user._id}).exec();

        resellGridData = gridData.filter(grid => grid.resellGridDetails !== null && grid.resellGridDetails.length > 0);

        resellGridData.forEach(grid => {
            uniqueId.add(grid.itemId);
        });

        for (const id of [...uniqueId]) {
            if (!resultData.some(item => item._id.toString() === id.toString())) {
                resultData.push(await Item.findById(id).exec());
            }
        }


        if (resultData && resultData.length > 0) {
            resultData.forEach(item => {
                approvedItems = item.toObject();
                if (checkDateDifference(item.uploadedAt) <= item.timePeriod) {
                    approvedItems['isProductNew'] = checkDateDifference(item['uploadedAt']) <= 7;
                    approvedItems['isFavourite'] = user['favourites'] !== undefined ? user['favourites'].includes(item['_id']) : false;
                    approvedItems['totalNumberOfUnits'] = item.unitsForSale;
                    approvedItems['isExpired'] = false;
                } else {
                    approvedItems['isExpired'] = true
                }
                itemArray.push(approvedItems);
            });
            finalResponse = response(true, "success", sortItems(itemArray));
        } else
            finalResponse = response(true, 'No item found', [])
    } catch (e) {
        finalResponse = response(false, e.message, []);
    }
    res.status(status.OK).send(finalResponse);
});

/**
 * @BodyParam: itemId
 * @BodyParam: status
 *
 * @description: update item status
 *
 * @return: success or error
 *
 * steps:
 * 1. find item by id
 * 2. if item found then update status
 * 3. else return error
 * */

router.put(routes.ITEM_APPROVAL, async (req, res) => {
    let finalResult;
    try {
        const filter = {_id: req.body['itemId']};
        const update = {status: req.body["status"]};
        await Item.updateOne(filter, update)
            .then(result => {
                finalResult = response(true, "success", result);
            })
            .catch(e => {
                finalResult = response(false, e.message, {});
            });
    } catch (err) {
        finalResult = response(false, err.message, {});
    }
    res.status(status.OK).send(finalResult);
});

router.delete(routes.DELETE_ITEMS, async (req, res) => {
    let finalResult;
    try {
        const id = req.body['itemId'];
        await Item.deleteOne({_id: id})
            .then(result => {
                finalResult = response(true, `item - ${id} is removed successfully`, result);
            }).catch(e => {
                finalResult = response(false, e.message, {})
            });
    } catch (e) {
        finalResult = response(false, e.message);
    }
    res.status(status.OK).send(finalResult);
});

router.get(route.TOTAL_PURCHASED_GRID_PER_ITEM, async (req, res) => {
    let finalResponse;
    try {
        let grid = await Grid.aggregate([
            {
                $match: {"paymentStatus": "Paid"}
            },
            {
                $group:
                    {
                        _id: "$itemId",
                        paymentStatus: {"$first": "$paymentStatus"},
                        totalGridCount: {$sum: {$size: "$smartKey"}}
                    }
            }
        ]);

        if (grid) {
            finalResponse = response(true, 'success', grid);
        } else {
            finalResponse = response(false, 'No data found', {});
        }
    } catch (e) {
        finalResponse = response(true, 'something wrong while performing grid collection', e.message);
    }
    res.json(finalResponse);
})

router.post(routes.ITEM_ABUSE, async (req, res) => {
    let finalResponse;

    if (req.body['itemId'] == null || (typeof req.body['itemId'] == 'undefined') || req.body['itemId'] === "") {
        finalResponse = response(false, "Error Occurred Please Check Mandatory Fields", "itemId missing");
    } else if (req.body['abuseComment'] == null || (typeof req.body['abuseComment'] == 'undefined') || req.body['abuseComment'] === "") {
        finalResponse = response(false, "Error Occurred Please Check Mandatory Fields", "abuseComment missing")
    } else {
        try {
            let userDetails = await User.findOne({_id: req.user.user_id}).exec();
            if (await Item.exists({_id: req.body.itemId})) {
                let item = await Item.findOne({_id: req.body.itemId}).select({'title': 1}).exec();

                let abuseItem = new Abuse({
                    itemId: item._id,
                    comment: req.body.abuseComment,
                    reportedUser: req.user.user_id
                });

                await abuseItem
                    .save()
                    .then(async result => {
                        console.log(result)
                        finalResponse = response(true, 'success', result);
                    let emailData = {
			to: 'nestmarket.email@gmail.com',
			subject: 'Report Abuse',
			username: 'Nest Market',
			message: `Hi there, <b> New Abuse has been created by userID : ${result.reportedUser}, message: ${result.comment}`    
		    }
			    email('nestadmin@gmail.com','Report Abuse','Nest Market Admin',`New Abuse has been created by userID : ${result.reportedUser}, message: ${result.comment}`);
                    })
                    .catch(err => {
                        finalResponse = response(false, 'error occured while saving abuse data', err.message);
                    });

            } else {
                finalResponse = response(false, 'Invalid Item id');
            }
        } catch (err) {
            finalResponse = response(false, "Error Occurred Please Check Mandatory Fields!", err.message);
        }
        res.json(finalResponse);
    }
});

router.post(route.IMAGE_APPEND, async (req, res) => {
    let finalResponse;
    try {
        let {src, image, x, y, width, height} = req.body;
        let path = await imageAppender(src, image, x, y, width, height);
        let url = req.protocol + "://" + req.get('host') + path;
        let editedImage = await new EditImageVersion({
            imageDetails: {
                path, x, y, width, height
            },
            uploadedUser: req.user.user_id
        })
        await editedImage.save();
        finalResponse = response(true, 'success', {productImageUrl: url});
        logger.info(logBody(req, 'image Append - success'))
    } catch (e) {
        finalResponse = response(false, 'error occured while appending image', e.message);
    }
    res.json(finalResponse);
})

router.post(route.ITEM_RENEWAL, async (req, res) => {
    let finalResponse;
    try {
        let {option, timePeriod, itemId, imagePath, price} = req.body;
        switch (option) {
            case renewal.NEW: {
                let gridDetails;
                try {
                    gridDetails = await Grid.aggregate([
                        {
                            $match: {
                                'paymentStatus': 'Paid',
                                'itemId': itemId
                            }
                        },
                        {
                            $lookup: {
                                from: 'payments',
                                localField: 'purchaseUserId',
                                foreignField: 'paymentUserId',
                                as: 'paymentData'
                            }
                        },
                        {
                            $unwind: {
                                path: "$paymentData",
                                "preserveNullAndEmptyArrays": true
                            }
                        },
                        {
                            $project: {
                                'smartKey': 1,
                                'paymentStatus': 1,
                                'itemId': 1,
                                'paymentData.paymentStatus': {$ifNull: ["$paymentData.paymentStatus", "Unspecified"]},
                                'paymentData.stripeAmount': {$ifNull: ["$paymentData.stripeAmount", "Unspecified"]},
                                'paymentData.totalAmount': {$ifNull: ["$paymentData.totalAmount", "Unspecified"]},
                                'paymentData.walletTransactionId': {$ifNull: ["$paymentData.walletTransactionId", "Unspecified"]},
                                'paymentData.paymentDate': {$ifNull: ["$paymentData.paymentDate", "Unspecified"]},
                                'paymentData.paymentUserId': {$ifNull: ["$paymentData.paymentUserId", "Unspecified"]}
                            }
                        }
                    ]);
                } catch (e) {
                    logger.error(logBody(req, 'something wrong while renewal processing', e.message));
                }

                if (gridDetails.paymentData && gridDetails.length > 0) await refundToBuyers(gridDetails);

                //changing grid and level values
                await new ImageDetails().shapeFinder(req, imagePath)
                    .then(async imageDetails => {
                        finalResponse = response(true, 'success', await Item.findOneAndUpdate({_id: itemId},
                            {
                                uploadedAt: Date.now(),
                                price: price,
                                timePeriod: timePeriod,
                                imageData: imageDetails
                            }, {new: true}));
                    })
                    .catch(error => finalResponse = response(false, 'failure', {message: error.message}));

                break;
            }
            case renewal.RENEW: {
                let item = await Item.findOneAndUpdate({_id: itemId},
                    {
                        timePeriod: timePeriod,
                        uploadedAt: Date.now(),
                        isRenewed: true,
                        $inc: {
                            renewCount: 1
                        }
                    },
                    {new: true}).exec();
                if (item) {
                    finalResponse = response(true, 'success', item);
                } else {
                    finalResponse = response(false, 'No item found', {});
                }
                break;
            }
        }
    } catch (e) {
        finalResponse = response(false, 'something wrong while performing item renewal', e.message);
    }
    res.json(finalResponse);
});

async function refundToBuyers(gridDetails) {
    for (let payment of gridDetails.paymentData) {
        let user = await User.findOneAndUpdate({id: paymentUserId}, {$inc: {'wallet.amount': payment.totalAmount}}, {new: true})
            .select({'wallet.id': 1, 'wallet.amount': 1}).exec();
        let wallet = await new Wallet({
            transactionType: 'Refund',
            amount: payment.totalAmount,
            transactionStatus: 'Paid',
            userWalletId: user.wallet.id
        });
        await wallet.save()
            .then(walletRefund => console.log(walletRefund))
            .catch(err => console.log(err.message));
    }
}

module.exports = router;
