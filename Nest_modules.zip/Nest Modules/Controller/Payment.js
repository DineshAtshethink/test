const express = require("express");
const route = require("../Utils/NestRoutes");
const { response } = require("../Utils/Response");
const { Payment } = require("../Model/PaymentSchema");
const Grid = require("../Model/ImageGridSchema");
const { Wallet } = require("../Model/WalletSchema");
const User = require("../Model/UserSchema");
const { Item } = require("../Model/ItemSchema");
const NestLog = require("../Logger/NestLog");
const { logBody } = require("../Logger/LogBody");
const Coupon = require("../Model/CouponCodeSchema");
const { checkDateDifference } = require("../Utils/DateDifference");
const CouponCode = require("../Model/CouponCodeSchema");
const stripe = require("stripe")(process.env.STRIPE_SECRET);
const Commission = require("../Model/Commission");
const bcrypt = require("bcrypt");
const { BuyerSchema } = require("../Model/BuyerCommission");
const { param } = require("express/lib/router");
const { SellerSchema } = require("../Model/SellerCommission");
const logger = new NestLog().logger;

const router = express.Router();

async function isGridUnderPurchase(gridMongoID) {
  try {
    if (
      gridMongoID &&
      typeof gridMongoID === "string" &&
      gridMongoID.length > 12
    ) {
      const mongoIds = await Grid.findOne(
        { _id: gridMongoID },
        { smartKey: 1 }
      ).exec();

      console.log("key:" + mongoIds.smartKey[0].split("_")[0]);
      let count = await Item.findOne(
        { _id: mongoIds.smartKey[0].split("_")[0] },
        { resellCount: 1 }
      );

      console.log(count.resellCount);

      isExist = await Grid.exists({
        smartKey: { $in: mongoIds.smartKey },
        paymentStatus: "Paid",
        isActive: true,
        key: { $gt: count.resellCount },
      });

      console.log(`isExist = ${isExist}`);
    } else {
      throw Error("Invalid grid id");
    }
    return isExist;
  } catch (e) {
    console.error(e.message);
  }
}

router.post(route.PAYMENT_INTENT, async (req, res) => {
  logger.info(logBody(req, "Inside payment Intent"));
  let { totalPrice, gridID, isWalletUsable, couponId } = req.body;
  let percent = 0,
    isResell = false;
  let finalResponse;
  if (!(await isGridUnderPurchase(gridID))) {
    //Buyer commission
    await Grid.findOne({ _id: gridID })
      .select("itemId")
      .exec()
      .then(async (gridData) => {
        if (gridData) {
          logger.info(logBody(req, "Grid data found"));
          await Item.findOne({ _id: gridData.itemId })
            .select("isResellAllowed")
            .exec()
            .then(async (itemData) => {
              if (itemData) {
                logger.info(logBody(req, "Item data found"));
                isResell = itemData.isResellAllowed;
              } else {
                logger.error(logBody(req, "Item data not found"));
                response(res, 400, "Item data not found");
              }
            })
            .catch((err) => {
              logger.error(logBody(req, "Error in finding item data", err));
            });
        }
      })
      .catch((err) => {
        logger.error(logBody(req, "Error in finding item"));
      });

    let actualTotalPrice = totalPrice;
    console.log(totalPrice);
    await BuyerSchema.findOne()
      .and([
        { minAmount: { $lte: totalPrice } },
        { maxAmount: { $gte: totalPrice } },
        { status: "Active" },
      ])
      .exec(async (err, buyer) => {
        if (err) {
          logger.error(logBody(req, "Error in finding buyer commission"));
        }
        if (buyer) {
          logger.info(logBody(req, "Buyer commission found"));
          percent = buyer.percentage;
          let newTotalPrice = totalPrice + (totalPrice * percent) / 100;
          totalPrice = newTotalPrice;
          logger.info(logBody(req, "Buyer commission is " + percent));
          logger.info(
            logBody(req, "Actual total price is " + actualTotalPrice)
          );
          let newCommission = new Promise(async (resolve, reject) => {
            if (percent > 0) {
              resolve(
                new Commission({
                  userId: req.user.user_id,
                  commissionPercent: percent,
                  commissionValue: Math.abs(newTotalPrice - actualTotalPrice),
                  actualAmount: actualTotalPrice,
                  totalAmount: newTotalPrice,
                  gridId: gridID,
                  commissionId: await buyer._id,
                  status: "completed",
                  commissionType: "Buyer",
                })
              );
            } else {
              reject("Percentage is not available");
            }
          });
          await newCommission
            .then(async (commission) => {
              logger.info(
                logBody(
                  req,
                  "Buyer Commission record created successfully",
                  commission
                )
              );
              commission
                .save()
                .then(async (result) => {
                  logger.info(
                    logBody(
                      req,
                      "Buyer Commission record saved successfully",
                      result
                    )
                  );
                })
                .catch((err) => {
                  logger.error(
                    logBody(
                      req,
                      "Error while saving buyer commission record",
                      err.message
                    )
                  );
                });
            })
            .catch((err) => {
              logger.error(
                logBody(
                  req,
                  "Error while creating buyer commission record",
                  err.message
                )
              );
            });
        }
      });
    if (isResell) {
      await SellerSchema.findOne()
        .and([
          { minAmount: { $lte: totalPrice } },
          { maxAmount: { $gte: totalPrice } },
          { status: "Active" },
        ])
        .exec()
        .then(async (result) => {
          logger.info(
            logBody(req, "Seller commission is fetched successfully", result)
          );
          let percentage = (totalPrice * result.percentage) / 100;
          totalPrice = actualTotalPrice - percentage;
          percent = result.percentage;
          logger.info(
            logBody(
              req,
              "Creating Seller commission record for current purchase",
              `gridID - ${gridID}`
            )
          );
          let newCommission = new Promise(async (resolve, reject) => {
            if (result.percentage > 0) {
              resolve(
                new Commission({
                  userId: req.user.user_id,
                  commissionPercent: result.percentage,
                  commissionValue: Math.abs(totalPrice - actualTotalPrice),
                  actualAmount: actualTotalPrice,
                  totalAmount: totalPrice,
                  gridId: gridID,
                  commissionId: await result._id,
                  status: "completed",
                  commissionType: "Seller",
                })
              );
            } else {
              reject("Percentage is not available");
            }
          });

          await newCommission
            .then(async (commission) => {
              logger.info(
                logBody(
                  req,
                  "Seller Commission record created successfully",
                  commission
                )
              );
              commission
                .save()
                .then(async (result) => {
                  logger.info(
                    logBody(
                      req,
                      "Seller Commission record saved successfully",
                      result
                    )
                  );
                })
                .catch((err) => {
                  logger.error(
                    logBody(
                      req,
                      "Error while saving seller commission record",
                      err.message
                    )
                  );
                });
            })
            .catch((err) => {
              logger.error(
                logBody(
                  req,
                  "Error while creating seller commission record",
                  err.message
                )
              );
            });
        })
        .catch((err) => {
          logger.error(
            logBody(
              req,
              "error occured while fetching seller commission",
              err.message
            )
          );
        });
    }

    let RemaningAmount = 0;
    try {
      if (gridID && totalPrice >= 0 && (await Grid.exists({ _id: gridID }))) {
        logger.info(logBody(req, "Input validation successful"));
        let walletTransactionId, user;
        let gridData = await Grid.findById(gridID)
          .select({ smartKey: 1, itemId: 1 })
          .exec();

        //fetching user wallet details
        if (isWalletUsable) {
          logger.info(logBody(req, "wallet is usable now"));
          user = await User.findOne(
            { _id: req.user["user_id"] },
            "wallet"
          ).exec();
          RemaningAmount = Math.abs(actualTotalPrice - user.wallet.amount);

          //if wallet amount is greater than 0, then deduction will happen and data will be updated in database
          if (user.wallet.amount > 0) {
            logger.info(
              logBody(req, "wallet validation success", user.wallet.amount)
            );
            await new Wallet({
              amount:
                Math.sign(user.wallet.amount - actualTotalPrice) > 0
                  ? actualTotalPrice
                  : user.wallet.amount,
              userWalletId: user.wallet.id,
              transactionType: "Purchase",
              totalPurchaseUnits: gridData.smartKey.length,
            })
              .save()
              .then(async (result) => {
                walletTransactionId = result["_id"];
                logger.info(logBody(req, "wallet transaction created", result));
                let updatedUserWallet = await User.findOneAndUpdate(
                  { _id: user._id },
                  {
                    $inc: {
                      "wallet.amount":
                        Math.sign(user.wallet.amount - actualTotalPrice) >= 0
                          ? actualTotalPrice * -1
                          : user.wallet.amount * -1,
                    },
                  },
                  { new: true }
                )
                  .select({ wallet: 1 })
                  .exec();
                logger.info(
                  logBody(req, "updated user wallet", updatedUserWallet)
                );
              })
              .catch((err) => {
                logger.error(logBody(req, err.message));
              });
          }
        }

        //generationg client secret for payment;
        logger.info(logBody(req, "creating payment data"));
        let payment = new Payment({
          sellerId: "NestMarket",
          gridId: gridID,
          clientSecret: isWalletUsable
            ? Math.sign(user.wallet.amount - actualTotalPrice) < 0
              ? await paymentIntent(actualTotalPrice)
              : null
            : actualTotalPrice > 0
            ? await paymentIntent(actualTotalPrice)
            : null,
          walletTransactionId: isWalletUsable ? walletTransactionId : null,
          stripeAmount: isWalletUsable
            ? Math.sign(user.wallet.amount - actualTotalPrice) < 0
              ? RemaningAmount
              : 0
            : actualTotalPrice,
          totalAmount: actualTotalPrice,
          paymentUserId: req.user.user_id,
          status: isWalletUsable
            ? Math.sign(user.wallet.amount - actualTotalPrice) >= 0
              ? "Done"
              : "Incomplete"
            : totalPrice > 0
            ? "Incomplete"
            : "Done",
          appliedCoupon: couponId
            ? (await Coupon.exists({ _id: couponId }))
              ? await Coupon.findById(couponId).select({ name: 1 }).exec()
              : Error("Invalid couppon").message
            : null,
        });

        await payment
          .save()
          .then(async (result) => {
            logger.info(logBody(req, "Payment data saved", result));
            if (result.stripeAmount === 0 && result.status === "Done") {
              let itemData = await Item.findById(gridData.itemId)
                .select({ isResellAllowed: 1 })
                .exec();
              console.table({ itemData: itemData._doc });
              await updateTotalPurchasedGrids(
                req,
                gridData.itemId,
                itemData._doc.isResellAllowed,
                gridData.smartKey,
                percent
              );
            }
            if (result.appliedCoupon != null)
              await Coupon.findOneAndUpdate(
                { _id: couponId },
                { $addToSet: { appliedUsers: req.user.user_id } },
                { new: true }
              ).exec();
            finalResponse = response(true, "success", result);
          })
          .catch((e) => {
            logger.error(logBody(req, "error while saving payment data"));
            finalResponse = response(
              false,
              "something wrong while saving payment data",
              e.message
            );
          });
      } else {
        logger.error(logBody(req, "Invalid gridId or total Price"));
        finalResponse = response(
          false,
          "failure",
          "Invalid grid Id or total Price",
          {}
        );
      }
    } catch (e) {
      logger.error(logBody(req, e.message));
      finalResponse = response(
        false,
        "error occuring while performing payment intent",
        e.message
      );
    }
  } else {
    logger.error(
      logBody(
        req,
        "one or more grid in selected grids is/are already purchased"
      )
    );
    finalResponse = response(
      false,
      "one or more grid in selected grids is/are already purchased"
    );
  }
  res.json(finalResponse);
});

async function paymentIntent(totalPrice) {
  let x = await stripe.paymentIntents.create({
    payment_method_types: ["card"],
    amount: Math.round(totalPrice * 100),
    currency: "usd",
    description: "Software development services",
    shipping: {
      name: "Jenny Rosen",
      address: {
        line1: "510 Townsend St",
        postal_code: "98140",
        city: "San Francisco",
        state: "CA",
        country: "US",
      },
    },
  });
  return await x.client_secret;
}

router.put(route.UPDATE_PAYMENT, async (req, res) => {
  let finalResponse;
  console.log("------------------------(1)----------------------------");
  logger.info(logBody(req, "inside payment update"));
  try {
    //require payment id and status
    let { paymentId, paymentStatus } = req.body;
    let isResellAllowed;
    if (paymentId && paymentStatus) {
      logger.info(logBody(req, "Input validation success"));

      //payment update
      let payment = await Payment.findOneAndUpdate(
        { _id: paymentId },
        {
          status: paymentStatus ? "Done" : "Failed",
        },
        { new: true }
      ).exec();

      payment != null
        ? logger.info(logBody(req, "updated payment details"))
        : logger.error(
            logBody(req, "Something wrong while updating payment", payment)
          );

      if (payment) {
        //wallet update
        let wallet = null;
        if (payment.walletTransactionId) {
          wallet = await Wallet.findOneAndUpdate(
            { _id: payment.walletTransactionId },
            { transactionStatus: paymentStatus ? "Paid" : "Failed" },
            { new: true }
          ).exec();
          wallet !== null
            ? logger.info(logBody(req, "updated wallet details"))
            : logger.error(
                logBody(req, "something wrong while updating wallet", wallet)
              );
        }
        //grid update
        let grid = await Grid.findOneAndUpdate(
          { _id: payment.gridId },
          { paymentStatus: paymentStatus ? "Paid" : "Failed" },
          { new: true }
        ).exec();
        grid !== null
          ? logger.info(logBody(req, "Updated grid details"))
          : logger.error(
              logBody(req, "something wrong while updating grid", grid)
            );

        let itemData = await Item.findById(grid.itemId)
          .select({ isResellAllowed: 1 })
          .exec();

        //user data update
        if (!paymentStatus) {
          let walletAmount = wallet ? wallet.amount : 0;
          let user = await User.findOneAndUpdate(
            { _id: req.user.user_id },
            { $inc: { "wallet.amount": walletAmount } },
            { new: true }
          )
            .select({ wallet: 1 })
            .exec();
          user !== null
            ? logger.info(
                logBody(req, "user wallet amount updated successfully", user)
              )
            : logger.error(
                logBody(req, "somthing wrong while updating user wallet")
              );
          logger.info(
            logBody(req, "payment Failed - updated", { payment, grid, wallet })
          );
          finalResponse = response(true, "payment Failed", {
            payment_id: payment.id,
            status: payment.status,
          });
        } else {
          console.log(
            "------------------------(2)----------------------------"
          );
          let percent = 0;
          await Payment.findById(paymentId)
            .select({ totalAmount: 1 })
            .exec()
            .then(async (payment) => {
              logger.info(logBody(req, "payment details", payment));
              let totalPrice = payment.totalAmount;
              await SellerSchema.findOne()
                .and([
                  { minAmount: { $lte: totalPrice } },
                  { maxAmount: { $gte: totalPrice } },
                  { status: "Active" },
                ])
                .exec()
                .then((result) => {
                  if (result) {
                    percent = result.percentage;
                  }
                })
                .catch((err) => {
                  logger.error(
                    logBody(req, "error while finding buyer schema", err)
                  );
                });
            })
            .catch((e) => {
              logger.error(
                logBody(req, "error while finding payment", e.message)
              );
            });

          await updateTotalPurchasedGrids(
            req,
            await grid.itemId,
            itemData.isResellAllowed,
            grid.smartKey,
            percent
          );
          logger.info(logBody(req, "success", { payment, grid, wallet }));
          finalResponse = response(true, "payment success", {
            payment_id: payment.id,
            status: payment.status,
          });
        }
      } else {
        logger.warn(logBody(req, "payment data should not be null"));
        finalResponse = response(
          false,
          "payment data should not be null",
          payment
        );
      }
    } else {
      logger.error(
        logBody(req, "paymentId or paymentStatus should not be null")
      );
      finalResponse = response(
        false,
        "paymentId or paymentStatus should not be null"
      );
    }
  } catch (e) {
    logger.error(logBody(req, e.message));
    finalResponse = response(
      false,
      "something wrong while updating payment transaction",
      e.message
    );
  }
  res.json(finalResponse);
});

async function validateUser(user_id, pass) {
  let user = await User.findById(user_id).exec();
  if (user) {
    return (
      (await bcrypt.compare(pass, user.password)) &&
      (await user.role) === "Admin"
    );
  } else {
    return false;
  }
}

router.put(route.ALLOW_RESELL, async (req, res) => {
  let finalResponse;
  try {
    let { itemId, pass } = req.body;
    console.log(`item id - ${itemId}`);

    let item = await Item.findById(itemId).exec();
    let isUserExist = await validateUser(req.user.user_id, pass);
    console.log(typeof item.price);
    /*try {
           await SellerSchema.findOne({$and: [{minAmount: {$lte: item.price}}, {maxAmount: {$gte: item.price}}, {status: 'Active'}]})
                .exec()
                .then(async commissionResult => {
                    if (commissionResult) {
                        let commission = new Commission({
                            userId: req.user.user_id,
                            commissionPercent: commissionResult.percentage,
                            commissionValue: (await item.price * commissionResult.percentage / 100),
                            actualAmount: await item.price,
                            totalAmount: await item.price - (await item.price * commissionResult.percentage / 100),
                            gridId: await item._id,
                            commissionId: await commissionResult._id,
                            status: 'completed',
                            commissionType: 'Seller'
                        });
                        await commission.save()
                            .then(result => {
                                logger.info(logBody(req, 'Seller commission is created successfully', result))
                            })
                            .catch(err => {
                                logger.error(logBody(req, 'Error occured while saving seller commissin', err.message))
                            })
                    }
                })
                .catch(err => {
                    logger.error(logBody(req, 'Error occured while finding seller commission', err.message));
                })
        } catch (e) {
            logger.error(req, 'Error occured while finding seller commission', e.message);
        }*/

    console.log(isUserExist);
    if (item && isUserExist) {
      let updatedItem = await Item.findByIdAndUpdate(
        itemId,
        {
          isResellAllowed: true,
          timePeriod: 3650,
          $inc: { resellCount: 1 },
        },
        { new: true }
      ).exec();

      if (updatedItem) finalResponse = response(true, "success", updatedItem);
      else finalResponse = response(true, "No Updated item found", {});
    } else {
      finalResponse = response(true, "Invalid item or password", {});
    }
  } catch (e) {
    console.error(e);
    finalResponse = response(
      false,
      "something wrong while updating resell allow data",
      e.message
    );
  }
  res.json(finalResponse);
});

async function updateTotalPurchasedGrids(
  req,
  itemId,
  isResellAllowed,
  smartKey,
  percent
) {
  console.log(`smartKey - ${smartKey}, percent - ${percent}`);
  logger.info(logBody(req, "inside update Total Purchased Grids"));
  let counter = 0;
  try {
    if (itemId) {
      logger.info(logBody(req, "validation success for itemId", itemId));

      if (!isResellAllowed) {
        logger.info(logBody(req, "Resell is not actived. usual process"));
        let grids = await Grid.findOneAndUpdate(
          {
            itemId: itemId,
            paymentStatus: "Paid",
            isActive: true,
          },
          { $inc: { key: 1 } },
          { new: true }
        )
          .select({ smartKey: 1 })
          .exec();

        console.log(grids);
        let itemUnitDetail =  await Item.findOne({_id: itemId}).select({_id:0, numberOfUnitsSold:1}).exec();
	      counter = itemUnitDetail.numberOfUnitsSold + smartKey.length;
        let totalNumberOfItemUnits = await Item.findOne({ _id: itemId })
          .select({ unitsForSale: 1 })
          .exec();
        let percentageSold =
          (counter / totalNumberOfItemUnits.unitsForSale) * 100;

       console.table({percentageSold, counter});		 
	      
        console.log(itemId);
        let item = await Item.findOneAndUpdate(
          { _id: itemId, isResellAllowed: false },
          {
            percentageSold: parseInt(percentageSold),
            numberOfUnitsSold: counter,
          },
          { new: true }
        )
          .select({
            percentageSold: 1,
            numberOfUnitsSold: 1,
            unitsForSale: 1,
            title: 1,
          })
          .exec();

        logger.info(
          logBody(req, "total units sold - updated successfully", item)
        );
      } else {
        logger.info(
          logBody(req, "Resell is activated. Further resell process started")
        );
        let finalResult = [],
          resellArray = [],
          wallet;
        console.table({ smartKey });
        for (const key of smartKey) {
          await Grid.find({
            smartKey: { $elemMatch: { $eq: key } },
            paymentStatus: "Paid",
            isActive: true,
          })
            .exec()
            .then(async (grids) => {
              console.log(`grids - ${grids}`);
              let index = 0;

              if (grids.length > 0) {
                for (let grid of grids) {
                  for (const resellData of grid.resellGridDetails) {
                    // console.log(`resellKey = ${resellData.key}, actual key = ${key}, isKeyMatched = ${resellData.key === key} isKeySold = ${resellData.isSold}`)
                    if (resellData.key === key && !resellData.isSold) {
                      index = grid.resellGridDetails.indexOf(resellData);
                      console.log(`index = ${index}`);
                      grid.resellGridDetails[index].isSold = true;

                      logger.info(
                        logBody(req, "Creating wallet data for sales")
                      );
                      wallet = await User.findById(grid.purchaseUserId)
                        .select({ wallet: 1 })
                        .exec();
                      resellArray.push({
                        price: resellData.price,
                        walletId: wallet.wallet.id,
                      });

                      let resellCounterr = await Item.findOne(
                        { _id: itemId },
                        { resellCount: 1 }
                      );

                      console.log("***********************************");
                      let updateGrid = await Grid.findOneAndUpdate(
                        { _id: grid._id },
                        {
                          resellGridDetails: grid.resellGridDetails,
                          $inc: { key: resellCounterr.resellCount + 1 },
                        },
                        { new: true }
                      ).exec();
                      console.log(`updateGrid - ${updateGrid}`);
                      console.log("***********************************");
                      if (updateGrid) {
                        logger.info(logBody(req, "resell grid updated"));
                        finalResult.push(updateGrid.resellGridDetails);
                      }
                    }
                  }
                }
              }
            })
            .catch((err) => {
              logger.error(logBody(req, "error in resell part", err));
            });
        }
        await updateSalesInWallet(req, resellArray, wallet, percent);
        logger.info(logBody(req, "resell part is updated", finalResult));
      }
    } else {
      logger.error(logBody(req, "Invalid item id"));
    }
  } catch (e) {
    logger.error(
      logBody(req, "error occured while processing totalunits sold", e.message)
    );
  }
}

/**
 * resellArray - price and walletId
 * */
async function updateSalesInWallet(req, resellArray, wallet, percent) {
  console.log(
    `Resell array length - ${resellArray.length}, percent - ${percent}`
  );
  let resellMapper = new Map();
  try {
    if (resellArray.length > 0) {
      //map price and count to individual wallet id
      resellArray.forEach((data) => {
        console.log(`data - ${data}`);
        if (resellMapper.size > 0 && resellMapper.has(data.walletId)) {
          let { price, count } = resellMapper.get(data.walletId);
          console.table({ price, count });
          count += 1;
          resellMapper.set(data.walletId, {
            price: Number(price) + Number(data.price),
            count: count,
          });
        } else {
          resellMapper.set(data.walletId, { price: data.price, count: 1 });
        }
      });

      console.log(resellMapper);
      console.log(resellMapper.size);
      //creating sale transaction to respective user

      for (let [key, value] of resellMapper) {
        let finalAmount =
          percent > 0
            ? Math.abs(value.price - (value.price * percent) / 100)
            : value.price;
        console.log(`finalAmount - ${finalAmount}`);
        let saleWallet = new Wallet({
          transactionType: "Sales",
          amount: finalAmount,
          transactionStatus: "Paid",
          userWalletId: key,
          totalPurchaseUnits: value.count,
        });
        console.table({
          walletId: wallet.wallet.id,
          amount: wallet.amount,
          totalPurchaseUnits: wallet.totalPurchaseUnits,
        });
        let userWalletUpdate = await User.findOneAndUpdate(
          { "wallet.id": wallet.wallet.id },
          { $inc: { "wallet.amount": finalAmount } },
          { new: true }
        ).exec();

        if (await userWalletUpdate) {
          logger.info(logBody(req, "user wallet updated", userWalletUpdate));
        } else {
          logger.error(
            logBody(req, "error occured while updating user wallet")
          );
        }

        await saleWallet
          .save()
          .then((result) =>
            logger.info(
              logBody(
                req,
                "sale amount credited to respective reseller",
                result
              )
            )
          )
          .catch((err) =>
            logger.error(
              logBody(
                req,
                "error occured while saving sale credit to wallet",
                err.message
              )
            )
          );
      }
    }
  } catch (e) {
    console.log(e.message);
  }
}

router.get(route.GET_PUBLISH_KEY, async (req, res) => {
  let finalResponse;
  try {
    finalResponse = response(true, "success", {
      publishedKey: process.env.PUBLISH_KEY,
    });
  } catch (e) {
    finalResponse = response(false, "failure", e.message);
  }
  res.json(finalResponse);
});

router.get(route.USER_TRANSACTION, async (req, res) => {
  logger.info(logBody(req, "Inside user transaction"));
  let finalResponse;
  try {
    let userId = req.query.userId;
    if (userId && (await User.exists({ _id: userId }))) {
      let user = await User.findById({ _id: userId }).exec();
      let userObject = user.toObject();
      if (userObject.favourites.length > 0) {
        let favItems = [];
        for (const itemId of userObject.favourites) {
          favItems.push(await Item.findById(itemId).exec());
        }
        userObject["favourite_items"] = favItems;
      }
      let grids = await Grid.find({ purchaseUserId: user["_id"] })
        .select({ purchaseUserId: 0, __v: 0 })
        .exec();

      if (grids && grids.length > 0) {
        let finalArray = new Set();
        for (const grid of grids) {
          let payment = await Payment.findOne({ gridId: grid["_id"] })
            .select({
              gridId: 0,
              paymentUserId: 0,
              __v: 0,
            })
            .exec();
          finalArray.add({ grid, payment });
        }
        Object.assign(userObject, { gridTransactionDetails: [...finalArray] });
      }
      finalResponse = response(true, "success", userObject);
    } else {
      finalResponse = response(false, "Invalid user id");
    }
  } catch (e) {
    logger.info(
      logBody(req, "something wrong while fetching user transaction", e.message)
    );
    finalResponse = response(
      false,
      "something wrong while fetchng user payment data",
      e.message
    );
  }
  res.json(finalResponse);
});

router.post(route.REFUND_TO_USER, async (req, res) => {
  let finalResponse;
  try {
    let itemId = req.body.itemId;
    if (
      itemId !== null &&
      itemId !== undefined &&
      (await Item.exists({ _id: itemId }))
    ) {
      let grids = await Grid.find({
        _id: req.body.itemId,
        paymentStatus: "Paid",
      }).exec();
      if (grids) {
        for (const grid of grids) {
          let payment = await Payment.findOne({ gridId: grid._id }).exec();
          if (payment) {
            let updatedUser = await User.findOneAndUpdate(
              { _id: purchaseUserId },
              { $inc: { "wallet.amount": payment.totalAmount } },
              { new: true }
            ).exec();
            await new Wallet({
              transactionType: "Refund",
              amount: payment.totalAmount,
              transactionStatus: "Paid",
              userWalletId: updatedUser.wallet.id,
            })
              .save()
              .then(
                (result) =>
                  (finalResponse = response(
                    true,
                    "Refund to wallet is successful",
                    result
                  ))
              )
              .catch(
                (err) =>
                  (finalResponse = response(
                    false,
                    "something wrong while updating wallet",
                    err.message
                  ))
              );
          } else {
            finalResponse = response(false, "No payment data found");
          }
        }
      } else {
        finalResponse = response(false, "No grid found for given item id");
      }
    }
  } catch (e) {
    res.json(finalResponse);
  }
});

router.get(route.ITEM_TRANSACTION, async (req, res) => {
  let finalResponse;
  try {
    let itemId = req.query.itemId;
    if (itemId && (await Item.exists({ _id: itemId }))) {
      let item = await Item.findOne({ _id: itemId }).exec();
      if (item) {
        let grids = await Grid.find({ itemId: item["_id"] }).exec();
        let itemObject = item.toObject();
        let transactionArray = new Set();
        if (grids !== null && grids.length > 0) {
          for (const grid of grids) {
            let payment = await Payment.findOne({ gridId: grid["_id"] })
              .select({
                __v: 0,
                gridId: 0,
              })
              .exec();
            let user = await User.findOne({ _id: grid["purchaseUserId"] })
              .select({
                __v: 0,
                password: 0,
                accessToken: 0,
                accountDetails: 0,
                source: 0,
              })
              .exec();
            transactionArray.add({ grid, payment, user });
          }
          Object.assign(itemObject, { itemTransaction: [...transactionArray] });
        }
        finalResponse = response(true, "success", itemObject);
      } else {
        finalResponse = response(false, "Invalid item id");
      }
    }
  } catch (e) {
    finalResponse = response(
      false,
      "something wrong while fetching item transaction",
      e.message
    );
  }
  res.json(finalResponse);
});

module.exports = router;
