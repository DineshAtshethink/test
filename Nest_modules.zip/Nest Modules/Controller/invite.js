const express = require("express");
const status = require("../Utils/NestHTTPStatusCodes");
const routes = require("../Utils/NestRoutes");
const {response} = require("../Utils/Response");
const  NestLog = require('../Logger/NestLog');
const {logBody} = require('../Logger/LogBody');
const logger = new NestLog().logger;

const router = express.Router();

router.get(routes.INVITE, async (req, res) => {
    logger.info(logBody(req, 'Inside user invite'));
    let finalResponse;
    finalResponse = response(
        true,
        "Success",
        {
            Google: process.env.GOOGLE,
            Apple: process.env.APPLE
        });
    logger.info(logBody(req,'AllOk user invite'));
    res.status(status.OK).send(finalResponse);
});

module.exports = router;