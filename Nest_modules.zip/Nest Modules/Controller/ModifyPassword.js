const express = require("express");
const status = require("../Utils/NestHTTPStatusCodes");
const route = require("../Utils/NestRoutes");
const { response } = require("../Utils/Response");
const { email } = require("../Utils/sendGridMailer");
const speakeasy = require("speakeasy");
const Otp = require("../Model/OtpSchema");
const User = require("../Model/UserSchema");
const bcrypt = require("bcrypt");
const saltRounds = 8;
const NestLog = require("../Logger/NestLog");
const { logBody } = require("../Logger/LogBody");
const logger = new NestLog().logger;

const router = express.Router();

router.post(route.FORGET_PASSWORD, async (req, res) => {
  logger.info(logBody(req, "Inside forget password"));
  let finalResponse;
  try {
    let receiverMail = req.body.emailID,
      filter = { emailID: receiverMail, status:'Active' };
    const user = await User.exists(filter);
    if (user) {
      logger.info(logBody(req, "User exists"));
      let otpUser = await User.findOne(filter).exec();
      let { otpSecret, token } = getOtp();
      // console.table({secret: otpSecret['hex'], token});
      const otp = await new Otp({
        secret: otpSecret.hex,
        otp: parseInt(token),
        userId: otpUser["_id"],
      });
      await otp
        .save()
        .then((result) => {
          let message = `Otp for reset password is given below. it valid for 60s.<br><br> <h4 style="color:red"> ${token} </h4>
          <br>
          `;
          email(
            receiverMail,
            "OTP Verification",
            otpUser.firstName + " " + otpUser.lastName,
            message
          );
        })
        .catch((err) => {
          logger.error(logBody(req, "user didn't match", err));
          finalResponse = response(false, "failure", err);
        });
      finalResponse = response(true, "Otp mail sent successfully", otpSecret.hex);
    }else if(await User.exists({emailID: receiverMail, status: 'Deleted'})){
    logger.error(logBody(req,'Given email id is already used but account is disabled'));
	    finalResponse = response(false, 'Given email id is already used but account is disabled');
    } else {
      logger.error(logBody(req, "Given email ID is not registered"));
      finalResponse = response(false, "Given email ID is not registered");
    }
  } catch (e) {
    logger.error(logBody(req, "user didn't match", e));
    finalResponse = response(false, "failure", e);
  }

  res.json(finalResponse);
});

router.post(route.VERIFY_PASSWORD, async (req, res) => {
  logger.info(logBody(req, "Inside verify password"));
  let token = req.body.otp;
  let secret = req.body.secret;
  let finalResult;

  try {
    const result = await verifyOtp(secret, token);
    // console.log(result)
    if (result) {
      logger.info(logBody(req, "AllOk Otp is verified successfully"));
      finalResult = response(true, "Otp is verified successfully", secret);
    } else {
      logger.error(logBody(req, "Incorrect otp"));
      finalResult = response(false, "Incorrect otp");
    }
  } catch (e) {
    logger.error(logBody(req, "Incorrect otp", e.message));
    finalResult = response(false, "Incorrect otp", e.message);
  }
  res.status(status.OK).send(finalResult);
});

router.post(route.NEW_PASSWORD, async (req, res) => {
  logger.info(logBody(req, "Inside new password"));
  let secret = req.body.secret;
  let { newPassword, confirmPassword } = req.body,
    finalResult;
  try {
    if (Object.is(newPassword, confirmPassword)) {
      let otp = await Otp.findOne({ secret: secret }).exec();
      // console.log(otp)
      if (otp) {
        let filter = { _id: otp["userId"] },
          update = { password: await bcrypt.hash(newPassword, saltRounds) };
        let user = await User.findByIdAndUpdate(filter, update);
        finalResult = response(true, "success", user, { new: true });
        logger.info(logBody(req, "AllOk new password successfully"));
      } else {
        logger.error(logBody(req, "Incorrect secret key"));
        finalResult = response(false, "Incorrect secret key");
      }
    } else {
      logger.error(logBody(req, "New password and confirm password"));
      finalResult = response(false, "New password and confirm password");
    }
  } catch (e) {
    logger.error(logBody(req, "something wrong", e.message));
    finalResult = response(false, "failure", e);
    // console.log(e);
  }
  res.json(finalResult);
});

function getOtp() {
  let otpSecret = speakeasy.generateSecret({ length: 20 });
  return {
    otpSecret,
    token: speakeasy.totp({
      secret: this.otpsecret,
      digits: 6,
      encoding: "base32",
      remaining: 60 - Math.floor((new Date().getTime() / 1000) % 60),
    }),
  };
}

function verifyOtp(secret, token) {
  return speakeasy.totp.verify({
    secret: secret.base32,
    encoding: "base32",
    token: token,
    window: 3,
  });
}

module.exports = router;
