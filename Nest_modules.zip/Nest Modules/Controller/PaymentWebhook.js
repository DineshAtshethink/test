const stripe = require('stripe');
const express = require('express');
const bodyParser = require('body-parser');
const app = express();

// This is your Stripe CLI webhook secret for testing your endpoint locally.
const endpointSecret = "whsec_tgsGJafRfulS6koe8yNxYrq4Alavr7ir";


app.post('/webhook',express.raw({type: 'application/json'}), async (request, response) => {
    console.log('Inside webhook')
    const sig = request.headers['stripe-signature'];
    console.log(request.rawBody);
    let event;
    try {
        event = stripe.webhooks.constructEvent(request.body, sig, endpointSecret);
    } catch (err) {
        console.log(err.message)
        response.status(400).send(`Webhook Error: ${err.message}`);
        return;
    }

    // Handle the event
    switch (event.type) {
        case 'payment_intent.succeeded':
            const paymentIntentData = event.data.object;
            console.log(`[${event.id}] PaymentIntent (${paymentIntentData.id}):(${paymentIntentData.status})`);
            // Then define and call a function to handle the event payment_intent.succeeded
            break;
        case 'subscription_schedule.canceled':
            const subscriptionSchedule = event.data.object;
            console.log(`[${event.id}] subscriptionSchedule  (${subscriptionSchedule.id}):(${subscriptionSchedule.status})`);
            break;
        case 'invoice.upcoming':
            const invoice1 = event.data.object;
            console.log(`[${event.id}] invoice1  (${invoice1.id}):(${invoice1.status})`);
            break;
        case 'charge.captured':
            const charge = event.data.object;
            console.log(`[${event.id}] charge (${charge.id}):(${charge.status})`);
            // Then define and call a function to handle the event charge.captured
            break;
        case 'invoice.payment_succeeded':
            const invoice = event.data.object;
            console.log(`[${event.id}] invoice (${paymentIntent.id}):(${paymentIntent.status})`);
            // Then define and call a function to handle the event invoice.payment_succeeded
            break;

        default:
            console.log(`Unhandled event type ${event.type}`);
    }

    // Return a 200 response to acknowledge receipt of the event
    response.send();
});

module.exports = app;