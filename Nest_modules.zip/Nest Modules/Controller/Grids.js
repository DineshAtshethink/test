require("dotenv").config();
const express = require("express");
const routes = require("../Utils/NestRoutes");
const status = require("../Utils/NestHTTPStatusCodes");
const { Item } = require("../Model/ItemSchema");
const ImageGrids = require("../Model/ImageGridSchema");
const { response } = require("../Utils/Response");
const mongoose = require("mongoose");
const NestLog = require("../Logger/NestLog");
const { logBody } = require("../Logger/LogBody");
const logger = new NestLog().logger;

const router = express.Router();

router.post(routes.ITEM_GRID, async (req, res) => {
  logger.info(logBody(req, "Inside item Grid"));
  let finalResult, statusCode;
  const { smartKey } = req.body;
  if (itemId == null || typeof itemId == "undefined" || itemId === "") {
    logger.info(logBody(req, "item should not be null"));
    finalResult = response(
      false,
      "Error Occurred Please Check Mandatory Fields",
      "itemId missing"
    );
    statusCode = status.CONFLICT;
    res.status(statusCode).send(finalResult);
  } else {
    try {
      //    itemId_trace_rows,cols_target_rows,cols --> format
      logger.info(logBody(req, "grid input - verification success"));
      await ImageGrids.find()
        .and([{ smartkey: { $in: smartkey } }, { paymentStatus: "Paid" }])
        .exec()
        .then((result) => {
          logger.info(logBody(req, "grid found", result["_id"]));
          finalResult = response(true, "success", result);
          statusCode = status.OK;
        })
        .catch((e) => {
          logger.error(
            logBody(req, "Error occured while fetching grid data", e.message)
          );
          finalResult = response(false, "Try after sometime!", e.message);
          statusCode = status.BAD_REQUEST;
        });
    } catch (err) {
      logger.error(
        logBody(req, "Error occured while fetching grid data", err.message)
      );
      finalResult = response(false, "Try after sometime!", err.message);
      statusCode = status.BAD_REQUEST;
    }
    res.status(statusCode).send(finalResult);
  }
});

router.put(routes.UPDATE_GRID, async (req, res) => {
  logger.info(logBody(req, "Inside update grid"));
  let { itemId, updatedPrice } = req.body,
    finalResponse;

  try {
    if (gridId !== null && gridId !== undefined && gridId !== "") {
      logger.info(logBody(req, "grid input - verification success", gridId));
      const grid = await ImageGrids.findOneAndUpdate(
        { _id: gridId },
        {
          updatedPrice,
          updatedPrice,
        },
        { new: true }
      ).exec();
      if (grid !== null) {
        logger.info(
          logBody(req, "Grid data is updated", {
            id: grid._id,
            payment: grid.payment,
          })
        );
        finalResponse = response(true, "success", {
          id: grid._id,
          payment: grid.payment,
        });
      } else {
        logger.warn(logBody(req, "Invalid grid Id", gridId));
        finalResponse = response(false, "failed", grid);
      }
    } else {
      logger.error(
        logBody(req, "grid Id should not be null or undefined or empty")
      );
      finalResponse = response(false, "grid Id should be valid data");
    }
  } catch (e) {
    logger.error(logBody(req, "Error occured while updating grid", e.message));
    finalResponse = response(
      false,
      "error occured while updating status",
      e.message
    );
  }
  res.json(finalResponse);
});

async function getSellerId(itemId, gridId) {
  let result = new Set();
  try {
    let item = await Item.findOne({ _id: itemId })
      .select({ isResellAllowed: 1, uploadedUser: 1 })
      .exec();
    for (const grid of gridId) {
      if (item !== null && !item.isResellAllowed) {
        result.add(item.uploadedUser);
      } else if (item !== null && item.isResellAllowed) {
        let getRelativeUser = await ImageGrids.find({
          smartKey: { $elemMatch: { $eq: grid } },
          isActive: true,
        })
          .sort({ _id: -1 })
          .select({ purchaseUserId: 1 })
          .limit(1)
          .exec();

        if (getRelativeUser.length > 0) {
          result.add(getRelativeUser[0].purchaseUserId);
        }
      }
    }
  } catch (e) {
    console.log("Error occured while fetching sellerId " + e.message);
  }
  return [...result];
}

function gridValidator() {}

router.post(routes.ADD_GRID, async (req, res) => {
  logger.info(logBody(req, "Inside add grid"));
  let finalResponse;
  let { actualPrice, totalCost, lvlInfo } = req.body;

  try {
    if (actualPrice && totalCost && lvlInfo) {
      logger.info(logBody(req, "grid input - validation success"));
      [itemId, , trace, , target] = lvlInfo[0].split("_");
      if (await Item.exists({ _id: itemId })) {
        let lvlArray = trace.split(",").map((i) => Number(i));
        console.table(lvlArray);
        let purchaseLevel = lvlArray.includes(-1) ? 1 : lvlArray.length / 2 + 1;
        let grid = await ImageGrids.find()
          .and([
            { smartKey: { $elemMatch: { $in: lvlInfo } } },
            { paymentStatus: "Paid" },
          ])
          .select({ _id: 1 })
          .exec();

        let itemData = await Item.findOne({ _id: itemId }).exec();
        console.log(
          "imagelevel: " +
            (await itemData.imageData.levels) +
            " - purchaseLvl : " +
            purchaseLevel
        );

        let isRightKey = (await itemData.imageData.levels) === purchaseLevel;

        if (
          isRightKey &&
          ((await Item.exists({ _id: itemId, isResellAllowed: true })) ||
            grid.length === 0)
        ) {
          try {
            logger.info(logBody(req, "Found grid"));
            let sellerId = await getSellerId(itemId, lvlInfo);

            const imageGrids = await new ImageGrids({
              actualPrice: actualPrice,
              totalCost: totalCost,
              smartKey: lvlInfo,
              purchaseLevel: purchaseLevel,
              itemId: itemId,
              purchaseUserId: req.user.user_id,
              sellerId: await sellerId[0],
            });

            await imageGrids
              .save()
              .then(async (result) => {
                req.gridId = result["_id"];
                logger.info(
                  logBody(req, "New grid is added successfully", req.gridId)
                );
                finalResponse = response(true, "success", result);
              })
              .catch((err) => {
                logger.error(
                  logBody(
                    req,
                    "something wrong while saving grid data",
                    err.message
                  )
                );
                finalResponse = response(
                  false,
                  "something wrong while saving grids",
                  err.message
                );
              });
          } catch (err) {
            logger.error(
              logBody(
                req,
                "something wrong while performing add grid details",
                err.message
              )
            );
            finalResponse = response(false, err, {});
          }
        } else {
          logger.error(logBody(req, "Invalid grid selection"));
          finalResponse = response(
            false,
            `Invalid grid or level selection. one of the grid is already purchased or Invalid level selection`
          );
        }
      } else {
        logger.error(logBody(req, "Invalid item id"));
        finalResponse = response(
          false,
          `given itemId - ${itemId} doesn't exist`
        );
      }
    } else {
      logger.error(logBody(req, "lvlInfo is not included in request"));
      finalResponse = response(false, "lvlInfo is not included in request");
    }
  } catch (e) {
    logger.error(logBody(req, e.message));
    finalResponse = response(
      false,
      "Something wrong while performing add grid data",
      e.message
    );
  }
  res.json(finalResponse);
});

module.exports = router;
