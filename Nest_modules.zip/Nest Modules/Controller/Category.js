const express = require("express");
const Category = require("../Model/CategorySchema");
const status = require("../Utils/NestHTTPStatusCodes");
const route = require("../Utils/NestRoutes");
const UploadFiles = require("../Utils/UploadFiles");
const { response } = require("../Utils/Response");
const fs = require("fs");
const uploadIcons = new UploadFiles().uploadFile("Icons", "./NestImages/");
const NestLog = require("../Logger/NestLog");
const { logBody } = require("../Logger/LogBody");
const { Item } = require("../Model/ItemSchema");
const logger = new NestLog().logger;

const router = express.Router();

router.post(route.ADD_CATEGORY, uploadIcons, async (req, res) => {
  logger.info(logBody(req, "Inside Add Category"));
  let finalResult;
  try {
    const request = req.body;
    const category = await new Category({
      title: request.title.charAt(0).toUpperCase() + request.title.substr(1),
      categoryImage: req.file.path,
      iconLink: req.protocol + "://" + req.get("host") + "/" + req.file.path,
      status: request.status,
    });

    await category
      .save()
      .then((result) => {
        if (result) {
          finalResult = response(true, "success", result);
          logger.info(logBody(req, "AllOk Category Added to Database"));
        }
      })
      .catch((e) => {
        finalResult = response(false, e.message, {});
        logger.error(
          logBody(req, "error occured while adding category", e.message)
        );
      });
  } catch (e) {
    finalResult = response(false, e.message, {});
    logger.error(
      logBody(req, "error occured while adding category", e.message)
    );
  }
  res.json(finalResult);
});

router.get(route.LIST_CATEGORY, async (req, res) => {
  logger.info(logBody(req, "Inside List Category"));
  let finalResult;
  try {
    const category = await Category.find({}).exec();

    if (category.length > 0) {
      logger.info(logBody(req, "AllOk Listing the category"));
      finalResult = response(true, "success", category);
    } else {
      let defaultCategory = new Category({ title: "Others" });
      await defaultCategory
        .save()
        .then((result) => {
          logger.info(logBody(req, "Other category added as default"));
          finalResult = response(true, "success", [result]);
        })
        .catch((err) => {
          logger.error(
            logBody(
              req,
              "Error occured while creating default category",
              e.message
            )
          );
          finalResult = response(true, "failure", e.message);
        });
    }
  } catch (e) {
    logger.error(logBody(req, "error during listing the category", e.message));
    finalResult = response(false, e.message, {});
  }
  res.status(status.OK).send(finalResult);
});

async function categoryValidator(req, res, next) {
  logger.info(logBody(req, "Inside Category Validator"));
  console.log(req.query.id);
  try {
    let id = req.query.id;
    let isCategoryExist = await Category.exists({ _id: id });
    isCategoryExist ? next() : res.send(response(false, "Invalid Category id"));
    logger.info(logBody(req, "AllOk Category Validator"));
  } catch (e) {
    logger.error(logBody(req, "error during category validator", e.message));
    res.json(response(false, "something wrong while validating category"));
  }
}

router.put(
  route.EDIT_CATEGORY,
  [categoryValidator, uploadIcons],
  async (req, res) => {
    logger.info(logBody(req, "Inside Edit Category"));
    console.log(req.body);
    let request = req.body,
      finalResult,
      statusCode;
    try {
      const filters = { _id: req.query.id };
      const update = {
        title: request.title,
        updatedAt: new Date().toUTCString(),
        status: request.status,
      };
      console.log(req.file);
      if (req.file !== null && req.file !== undefined) {
        logger.info(logBody(req, "Inside Edit Category with Image"));
        update.categoryImage = req.file.path;
        update.iconLink =
          req.protocol + "://" + req.get("host") + "/" + req.file.path;
      }

      await Category.findOneAndUpdate(filters, update, { new: true })
        .then((result) => {
          finalResult = response(true, "success", result);
          logger.info(logBody(req, "AllOk Category is edited Successfully"));
          statusCode = status.OK;
        })
        .catch((e) => {
          finalResult = response(false, e.message, {});
          logger.error(
            logBody(req, "error occured while editing category", e.message)
          );
          statusCode = status.BAD_REQUEST;
        });
    } catch (e) {
      finalResult = response(false, e.message, {});
      logger.error(
        logBody(req, "error occured while editing category", e.message)
      );
      statusCode = status.BAD_REQUEST;
    }
    res.status(statusCode).send(finalResult);
  }
);

router.delete(route.DELETE_CATEGORY, async (req, res) => {
  logger.info(logBody(req, "Inside delete Category"));
  let finalResult;
  try {
    const categoryId = req.body["categoryId"];
    if (!(await Item.exists({ "category.id": categoryId }))) {
      const category = await Category.findOne({ _id: categoryId }).exec();
      let path = await category["categoryImage"];
      fs.unlinkSync(path);
      category != null ? await Category.deleteOne({ _id: categoryId }) : null;
      finalResult = response(
        true,
        `category - ${categoryId} is removed successfully`,
        category
      );
      logger.info(logBody(req, "AllOk Category  is removed successfully"));
    } else {
      finalResult = response(
        false,
        `Current category have some active items. so unable to delete it`
      );
    }
  } catch (e) {
    finalResult = response(false, e.message, {});
    logger.error(
      logBody(req, "Error occured while removing category", e.message)
    );
  }
  res.status(status.OK).send(finalResult);
});

module.exports = router;
