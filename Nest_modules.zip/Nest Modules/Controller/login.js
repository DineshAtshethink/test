require("dotenv").config();
const bcrypt = require("bcrypt");
const express = require("express");
const status = require("../Utils/NestHTTPStatusCodes");
const routes = require("../Utils/NestRoutes");
const { response } = require("../Utils/Response");
const User = require("../Model/UserSchema");
const jwt = require("jsonwebtoken");
const NestLog = require("../Logger/NestLog");
const { logBody } = require("../Logger/LogBody");
const logger = new NestLog().logger;

const router = express.Router();

router.post(routes.LOGIN, (req, res) => {
  logger.info(logBody(req, "Inside login"));
  let request = req.body;
  User.findOne({ emailID: request.email }, async (err, user) => {
    if (err) {
      logger.error(
        logBody(req, "Given user is not registered yet", err.message)
      );
      res
        .status(status.NOT_FOUND)
        .send(
          response(false, "Given user is not registered yet", {
            message: err.message,
          })
        );
    } else {
      if (user) {
        let finalResponse = {};
        if (user.status !== "Active") {
          logger.error(logBody(req, "Given user not active"));
          res
            .status(status.NOT_FOUND)
            .send(response(true, "Given user is not active", {}));
          return;
        }
        try {
          await bcrypt.compare(
            request.password,
            user.password,
            async (err, result) => {
              console.log(result);
              if (result) {
                const { emailID } = user;
                user["accessToken"] = jwt.sign(
                  { user_id: user._id, emailID, userKey: user.userKey },
                  process.env.AUTH_SECRET,
                  {
                    expiresIn: "100d",
                  }
                );
                await user.save();
                finalResponse = {
                  status: true,
                  message: "success",
                  body: {
                    username: user["firstName"] + " " + user["lastName"],
                    accessToken: user["accessToken"],
                  },
                };
                logger.info(logBody(req, "AllOk user login"));
                res.status(status.OK).send(finalResponse);
              } else {
                logger.error(
                  logBody(req, "invalid password. kindly try again", err)
                );
                res
                  .status(status.OK)
                  .send(
                    response(false, "invalid password. kindly try again", err)
                  );
              }
            }
          );
        } catch (error) {
          logger.error(logBody(req, "user didn't match", error.message));
          res
            .status(status.OK)
            .send(response(true, "user didn't match", error.message));
        }
      } else {
        logger.error(logBody(req, "Given user is not registered yet"));
        res
          .status(status.NOT_FOUND)
          .send(response(false, "Given user is not registered yet", {}));
      }
    }
  });
});

module.exports = router;
