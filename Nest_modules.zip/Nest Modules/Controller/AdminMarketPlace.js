const express = require('express')
const {response} = require('../Utils/Response');
const {Item} = require('../Model/ItemSchema');
const User = require('../Model/UserSchema');
const route = require('../Utils/NestRoutes');
const NestLog = require('../Logger/NestLog');
const {logBody} = require('../Logger/LogBody');
const logger = new NestLog().logger;

const router = express.Router();

router.get(route.ADMIN_SEARCH_FILTER,async (req, res) => {
    logger.info(logBody(req, 'Admin Search Filter'));
    let {category, itemStatus, paymentStatus, paidDate} = req.query, finalResponse;

    try {
        let itemArray=[],item;
        if(category !== undefined)
             item = await Item.find({'category.id':category}).exec();
        else if(itemStatus!== undefined)
            item  = await Item.find({status:itemStatus}).exec();
        else if(paymentStatus!== undefined)
            item = await Item.find({paymentStatus: paymentStatus}).exec();
        else if(paidDate !== undefined)
            item = await Item.find({paidDate: new Date(paidDate).toLocaleDateString()}).exec();

        if(item.length > 0){
            logger.info(logBody(req, 'Admin Search Filter', 'Success'));
            for (const item1 of item) {
                let data = item1.toObject();
                let user = await User.findById(data['uploadedUser']).exec();
                console.log(user)
                data['Asset Holder Name'] =user.firstName+' '+user.lastName;
                data['Mobile'] = user.mobile;
                itemArray.push(data);
            }
            finalResponse = response(true, 'success', itemArray);
        }
        else{
            logger.info(logBody(req, 'Admin Search Filter', 'No Data Found'));
            finalResponse = response(false, 'No data found')
        }

    } catch (e) {
        logger.error(logBody(req, 'Admin Search Filter', 'Error', e.message));
        finalResponse = response(false, 'error occured while filtering',e.message);
    }
    res.json(finalResponse);
});

module.exports = router;

