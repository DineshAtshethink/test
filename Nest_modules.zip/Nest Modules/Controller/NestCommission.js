const express = require('express');
const {response} = require('../Utils/Response');
const {BuyerSchema} = require('../Model/BuyerCommission');
const {SellerSchema} = require('../Model/SellerCommission');
const route = require('../Utils/NestRoutes');
const CommissionSchema = require('../Model/Commission');
const NestLog = require('../Logger/NestLog');
const {logBody} = require('../Logger/LogBody');
const logger = new NestLog().logger;
const router = express.Router();

router.post(route.CREATE_NEST_COMMISSION,async (req,res)=>{
    logger.info(logBody(req, 'Inside Create Nest Commission'));
   let finalResponse;
   try{
       let {type,minAmount,maxAmount,percentage} = req.body;
       if(type) {
           logger.info(logBody(req, 'Type is present'));
           let schemaObject = {
               minAmount: minAmount,
               maxAmount: maxAmount,
               percentage: percentage
           };

           if (Object.is(type, 'Buyer')) {
               logger.info(logBody(req,'type is buyer'));
              let buyerCommission =  new BuyerSchema(schemaObject);
              await buyerCommission.save()
                  .then(result => {
                      logger.info(logBody(req, 'Buyer Commission Created'));
                      finalResponse = response(true,'success',result);
                  })
                  .catch(error =>{
                      logger.error(logBody(req, 'Buyer Commission Creation Failed'));
                     finalResponse = response(false ,'error while saving buyer commission',error.message);
                  });
           } else if (Object.is(type, 'Seller')) {
               logger.info(logBody(req,'type is seller'));
                let sellerCommission = new SellerSchema(schemaObject);
                await sellerCommission.save()
                    .then(result => {
                        logger.info(logBody(req, 'Seller Commission Created'));
                        finalResponse = response(true,'success',result);
                    })
                    .catch(error =>{
                        logger.error(logBody(req, 'Seller Commission Creation Failed'));
                        finalResponse = response(false ,'error while saving seller commission',error.message);
                    });
           }
       }else
       {
           logger.error(logBody(req, 'Type is not present'));
           finalResponse = response(false,'Invalid type value',type);
       }
   }catch (e) {
       logger.error(logBody(req, 'Error while creating commission',e.message));
       finalResponse = response(false,'something wrong while processing commission',e.message);
   }
   res.json(finalResponse);
});

router.put(route.UPDATE_NEST_COMMISSION,async (req,res)=>{
    logger.info(logBody(req, 'Inside Update Nest Commission'));
    let finalResponse;
    try{
        let {commissionId, minAmount,maxAmount,percentage} = req.body;
        if(commissionId)
        {
            logger.info(logBody(req, 'Commission Id is present'));
            let filter = {_id: commissionId};
            let update = {minAmount,maxAmount,percentage};
            update.updatedAt = new Date().toUTCString();
            let updatedResult = {};

            if(await BuyerSchema.exists({_id:commissionId}))
                 updatedResult = await BuyerSchema.findOneAndUpdate(filter,update,{new:true}).exec();
            else if(await SellerSchema.exists({_id:commissionId}))
                updatedResult = await SellerSchema.findOneAndUpdate(filter,update,{new:true}).exec();

            if(updatedResult)
            {
                logger.info(logBody(req, 'Commission Updated'));
                finalResponse = response(true,'success',updatedResult);
            }
            else
            {
                logger.error(logBody(req, 'Commission Updation Failed'));
                finalResponse = response(false, 'No updated result',{});
            }
        }
        else {
            logger.error(logBody(req, 'Commission Id is not present'));
            finalResponse = response(false,'Invalid commission id',{});
        }
    }catch (e) {
        logger.error(logBody(req, 'Error while updating commission',e.message));
        finalResponse = response(false,'something wrong while updating commission data',e.message);
    }
    res.json(finalResponse);
});

router.get(route.GET_NEST_COMMISSION,async (req, res) => {
    logger.info(logBody(req, 'Inside Get Nest Commission'));
    let finalResponse;
    try {
            let commission, buyerCommission, sellerCommission;
                buyerCommission = await BuyerSchema.find({}).exec();
                sellerCommission = await SellerSchema.find({}).exec();
                commission = [...setTypeToCommission(buyerCommission,'Buyer'), ...setTypeToCommission(sellerCommission,'seller')];
            if (commission && commission.length > 0) {
                logger.info(logBody(req, 'Commission Found'));
                finalResponse = response(true, 'success', commission);
            } else {
                logger.error(logBody(req, 'Commission Not Found'));
                finalResponse = response(false, 'No data found');
            }
    } catch (e) {
        logger.error(logBody(req, 'Error while getting commission', e.message));
        finalResponse = response(false, 'something wrong while fetching commission',e.message);
    }
    res.json(finalResponse);
});

function setTypeToCommission(commission, type){
    let newCommission = [];
    commission.forEach(comm => {
        let c = comm.toObject();
        c['type'] = type;
        newCommission.push(c);
    });
    return newCommission;
}

router.delete(route.DELETE_NEST_COMMISSION,async (req,res)=>{
    logger.info(logBody(req, 'Inside Delete Nest Commission'));
    let finalResponse;
    try{
        let {commissionId} = req.body;
        let deletedResult = {};
        if(commissionId)
        {
            logger.info(logBody(req, 'Commission Id is present'));
            if(await BuyerSchema.exists({_id:commissionId}))
            {
                logger.info(logBody(req, 'Commission Type is Buyer'));
                deletedResult = await BuyerSchema.deleteOne({_id:commissionId});
            }else if(await SellerSchema.exists({_id:commissionId})){
                logger.info(logBody(req, 'Commission Type is Seller'));
                deletedResult = await SellerSchema.deleteOne({_id:commissionId});
            }
            if(deletedResult)
            {
                logger.info(logBody(req, 'Commission Deleted'));
                finalResponse = response(true,'success',deletedResult);
            }
            else {
                logger.error(logBody(req, 'Commission Deletion Failed'));
                finalResponse = response(false,'No delete data found',deletedResult);
            }
        }
        else {
            logger.error(logBody(req, 'Commission Id is not present'));
            finalResponse = response(false,'Invalid commission id',commissionId);
        }
    }catch (e) {
        logger.error(logBody(req, 'Error while deleting commission',e.message));
        finalResponse = response(false,'something wrong while deleting commission data',e.message);
    }
    res.json(finalResponse);
});

router.get(route.GET_COMMISSION_DETAILS, async function (req, res) {
    logger.info(logBody(req, 'Inside Get Commission Details'));
    let finalResponse;
    try {
        let {type, commissionId} = req.query, options = {};
        if(type === 'buyer') {
            logger.info(logBody(req, 'Commission Type is Buyer'));
            options = {commissionType: 'Buyer'};
        }
        else if(type === 'seller') {
            logger.info(logBody(req, 'Commission Type is Seller'));
            options = {commissionType: 'Seller'};
        }

        if(commissionId)
        {
            logger.info(logBody(req, 'Commission Id is present'));
            options._id = commissionId;
        }

        const commission = await CommissionSchema.find(options).exec();
        if (commission && commission.length > 0) {
            logger.info(logBody(req, 'Commission Found'));
            finalResponse = response(true, 'success', commission);
        } else {
            logger.error(logBody(req, 'Commission Not Found'));
            finalResponse = response(false, 'No data found');
        }
    } catch (e) {
        logger.error(logBody(req, 'Error while getting commission', e.message));
        finalResponse = response(false, 'something wrong while fetching commission', e.message);
    }
    return res.json(finalResponse);
});



module.exports = router;