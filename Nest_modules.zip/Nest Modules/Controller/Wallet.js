const express = require("express");
const { Wallet } = require("../Model/WalletSchema");
const route = require("../Utils/NestRoutes");
const types = require("../Utils/WalletType");
const { response } = require("../Utils/Response");
const User = require("../Model/UserSchema");
const NestLog = require("../Logger/NestLog");
const { logBody } = require("../Logger/LogBody");
const logger = new NestLog().logger;
const router = express.Router();

router.post(route.WALLET_TRANSACTION, async (req, res) => {
  logger.info(logBody(req, "Wallet transaction initiated"));

  let finalResponse;

  try {
    let { type, walletId, amount } = req.body;
    let wallet;

    switch (type) {
      case types.REFUND: {
        logger.info(logBody(req, "Refund initiated"));
        wallet = await createWalletTransaction(req, type, walletId, amount)
          .then((result) => {
            logger.info(logBody(req, "Refund data created", result));
            finalResponse = response(
              true,
              "Purchased Amount is refunded due to item unsold",
              result
            );
          })
          .catch((err) => {
            logger.error(
              logBody(
                req,
                "something wrong while creating the refund process",
                err.message
              )
            );
            finalResponse = response(
              false,
              "Something wrong while issuing result",
              err.message
            );
          });
        break;
      }
      case types.REDEEM: {
        logger.info(logBody(req, "Redeem initiated"));
	if(!await Wallet.exists({userWalletId: walletId, transactionStatus: 'Pending'})){
	      await createWalletTransaction(req, type, walletId, amount)
          .then((result) => {
            logger.info(logBody(req, "Redeem data created", result));
            if (result.isBankDetailsExist && result.walletAmount > 0)
              finalResponse = response(
                true,
                "Your redeem request is submitted successfully, we will notify you once redeem is done",
                result
              );
            else if (result.walletAmount <= 0) {
              finalResponse = response(
                false,
                "You do not have sufficient balance to redeem",
                result
              );
            } else
              finalResponse = response(true, "No bank details found", result);
          })
          .catch((err) => {
            logger.error(
              logBody(
                req,
                "Error occured while processing redeem process",
                err.message
              )
            );
            finalResponse = response(
              false,
              "Something wrong while doing redeem process",
              err.message
            );
          });
	}else{
	finalResponse = response(true, 'You have raised redeem request. check after sometime');      
	}
		break;
      }
      default: {
        logger.warn(logBody(req, "Invalid Transaction type"));
        finalResponse = response(false, "Incorrect Trasaction type");
      }
    }
  } catch (e) {
    logger.error(
      logBody(req, "Error occured while adding wallet details", e.message)
    );
    finalResponse = response(
      false,
      "error occured while adding wallet details",
      e.message
    );
  }

  logger.info(logBody(req, "wallet transaction ended"));
  res.json(finalResponse);
});

async function createWalletTransaction(req, ...args) {
  logger.info(logBody(req, "Inside create wallet transact"));
  let userBankData = await User.findOne({ _id: req.user.user_id })
      .select({ accountDetails: 1 })
      .exec(),
    result = {};
  let isBankDataExist = false;
  console.log(userBankData.accountDetails);

  let status = userBankData.accountDetails.accountNumber ? "Pending" : "Failed";

  let data = await new Wallet({
    transactionType: args[0],
    userWalletId: args[1],
    amount: args[2],
    transactionStatus: status,
  }).save();

  if (
    userBankData.accountDetails.accountNumber &&
    Object.keys(userBankData.accountDetails).length !== 0
  ) {
    let filter = { "wallet.id": args[1] },
      option;

    if (args[0] === "Refund") {
      option = { $inc: { "wallet.amount": args[2] } };
    } else if (args[0] === "Redeem") {
      option = { $inc: { "wallet.amount": args[2] * -1 } };
    }

    console.table({ filter, option });
    let walletAmount = await User.findOne(filter)
      .select({ "wallet.amount": 1 })
      .exec();
    console.table({ wallet: await walletAmount._doc.wallet.amount });
    let walletUpdated =
      (await walletAmount._doc.wallet.amount) > 0
        ? (await data.save()) &&
          (await User.findOneAndUpdate(filter, option, { new: true }).exec())
        : {};
    isBankDataExist = true;
    result =
      (await walletAmount._doc.wallet.amount) > 0 ? await data.toObject() : {};
    result["isBankDetailsExist"] = isBankDataExist;
    result["walletAmount"] = await walletAmount._doc.wallet.amount;
    logger.info(logBody(req, "wallet updated", walletUpdated));
  } else {
    data = await data.save();
    result = await data.toObject();
    result["isBankDetailsExist"] = isBankDataExist;
  }
  return result;
}

router.get(route.GET_INDIVIDUAL_USER_TRANSACTION, async (req, res) => {
  let finalResponse;
  try {
    let walletId = req.query.walletId;
    if (walletId && (await User.exists({ "wallet.id": walletId }))) {
      let walletData = await Wallet.find({ userWalletId: walletId }).exec();
      console.log(walletData);
      if (walletData.length) {
        finalResponse = response(true, "success", walletData);
      } else {
        finalResponse = response(false, "No data found", []);
      }
    } else {
      finalResponse = response(false, "Invalid wallet id", []);
    }
  } catch (e) {
    finalResponse = response(
      false,
      "something wrong while fetching user wallet data",
      e.message
    );
  }
  res.json(finalResponse);
});

router.get(route.GET_WALLET_TRANSACTION, async (req, res) => {
  logger.info(logBody(req, "Inside get wallet transaction"));
  let finalResponse;
  try {
    let walletId = req.query.id;

    const walletData = await Wallet.find({ userWalletId: walletId })
      .sort({ _id: -1 })
      .exec();
    if (walletData.length > 0) {
      logger.info(logBody(req, "wallet data found", walletData));
      finalResponse = response(true, "success", walletData);
    } else {
      logger.info(logBody(req, "No data found"));
      finalResponse = response(true, "No data found", []);
    }
  } catch (e) {
    logger.error(
      logBody(req, "Error occured while fetching wallet data", e.message)
    );
    finalResponse = response(
      false,
      "Something wrong while fetching wallet details",
      e.message
    );
  }
  res.json(finalResponse);
});

router.get(route.GET_USER_WALLET_AMOUNT, async (req, res) => {
  let finalResponse;
  try {
    let userId = req.user.user_id;
    let userData = await User.findOne({ _id: userId })
      .select({ wallet: 1 })
      .exec();
    if (userData) {
      finalResponse = response(true, "success", userData);
    } else {
      finalResponse = response(false, "No user found");
    }
  } catch (e) {
    finalResponse = response(
      false,
      "something wrong while fetchinng wallet data",
      e.message
    );
  }
  res.json(finalResponse);
});

router.get(route.GET_WITHDRAWAL_REQUEST, async (req, res) => {
  logger.info(logBody(req, "Inside get withdrawal request"));
  let finalResponse;
  try {
    let withdrawalData = await Wallet.find({
      transactionType: "Redeem",
    }).exec();
    let updatedData = [];
    if (withdrawalData && withdrawalData.length > 0) {
      logger.info(logBody(req, "withdrawal data found", withdrawalData));
      for (const data of withdrawalData) {
        let x = data.toObject();
        let user = await User.findOne({ "wallet.id": data["userWalletId"] })
          .select({ _id: 1 })
          .exec();
        x["userId"] = user._id;
        updatedData.push(x);
      }
      logger.info(logBody(req, "withdrawal data - success", updatedData));
      finalResponse = response(200, "success", updatedData);
    } else {
      logger.info(logBody(req, "No data found"));
      finalResponse = response(true, "No data found", updatedData);
    }
  } catch (e) {
    logger.error(
      logBody(req, "Error occured while fetching withdrawal data", e.message)
    );
    finalResponse = response(
      false,
      "something wrong while fetching withdraw data",
      e.message
    );
  }
  res.json(finalResponse);
});

router.put(route.UPDATE_WITHDRAWAL_REQUEST, async function (req, res) {
  logger.info(logBody(req, "Inside update withdrawal request"));
  let finalResponse;
  try {
    let { transactionId, status } = req.body;
    if (transactionId && status) {
      logger.info(
        logBody(req, "transactionId and status found", transactionId, status)
      );
      let filter = { _id: transactionId };
      let update = { transactionStatus: status };
      let updatedRequest = await Wallet.findOneAndUpdate(filter, update, {
        new: true,
      }).exec();
      if (updatedRequest) {
        logger.info(logBody(req, "updated request", updatedRequest));
        finalResponse = response(true, "success", updatedRequest);
      } else {
        logger.info(logBody(req, "No data found"));
        finalResponse = response(true, "No data found", {});
      }
    } else {
      logger.info(logBody(req, "transactionId and status not found"));
      finalResponse = response(false, "Invalid transactionId or status");
    }
  } catch (e) {
    logger.error(
      logBody(req, "Error occured while updating withdrawal request", e.message)
    );
    finalResponse = response(
      false,
      "something wrong while updating withdraw request"
    );
  }
  res.json(finalResponse);
});

router.delete(route.DELETE_WITHDRAWAL_REQUEST, async (req, res) => {
  logger.info(logBody(req, "Inside delete withdrawal request"));
  let finalResponse;
  try {
    let transactionId = req.query.id;
    if (transactionId) {
      logger.info(logBody(req, "transactionId found", transactionId));
      let filter = { _id: transactionId };
      let deletedData = await Wallet.deleteOne(filter).exec();
      if (deletedData) {
        logger.info(logBody(req, "deleted data", deletedData));
        finalResponse = response(true, "success", deletedData);
      } else {
        logger.info(logBody(req, "No data found"));
        finalResponse = response(true, "No data found", {});
      }
    } else {
      logger.info(logBody(req, "transactionId not found"));
      finalResponse = response(
        false,
        "Invalid id. please try again",
        transactionId
      );
    }
  } catch (e) {
    logger.error(
      logBody(req, "Error occured while deleting withdrawal request", e.message)
    );
    finalResponse = response(
      false,
      "Error occured while deleting withdraw data",
      e.message
    );
  }
  res.json(finalResponse);
});

module.exports = router;
