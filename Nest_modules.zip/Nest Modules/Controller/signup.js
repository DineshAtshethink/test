const User = require("../Model/UserSchema");
const express = require("express");
const status = require("../Utils/NestHTTPStatusCodes");
const routes = require("../Utils/NestRoutes");
const jwt = require("jsonwebtoken");
const sha256 = require("crypto-js/sha256");
const { response } = require("../Utils/Response");
const router = express.Router();

/**
 * @BodyParam email string required
 * @BodyParam password string required
 * @BodyParam name string required
 *
 * @description This route is used to create a new user
 *
 * @returns {object}
 *
 * steps:
 * 1. check if user already exists
 * 2. if user does not exist, create user
 * 3. if user exists, return error
 * 4. if user created, return success
 */

router.post(routes.SIGN_UP, async (req, res) => {
  let request = req.body;
  const { emailID, pass } = req.body;
  if (!emailID)
    res
      .status(status.CONFLICT)
      .send(response(false, "emailID is not provided", {}));
  if (request.source === "MobileApp" && pass === "" && !pass)
    res.status(status.CONFLICT).send(response(false, "Invalid Password", {}));

  let finalResponse;
  try {
    if (await User.exists({ emailID, status: "Deleted" })) {
      finalResponse = response(
        false,
        "Given email id is already used. try again with different email ID"
      );
    } else {
      let user = await User.findOne({ emailID: request.emailID });
      if (user && Object.keys(user).length !== 0) {
        if (user.source === "Mobile App") {
          finalResponse = response(false, "user already exist", {});
        } else {
          let token = jwt.sign(
            {
              user_id: user.id,
              emailID: request.emailID,
            },
            process.env.AUTH_SECRET,
            {
              expiresIn: "100d",
            }
          );
          let updatedUser = await User.findOneAndUpdate(
            { _id: user["_id"] },
            { accessToken: token },
            { new: true }
          )
            .select({ accessToken: 1, firstName: 1, lastName: 1 })
            .exec();
          finalResponse =
            updatedUser != null
              ? response(true, "success", {
                  userName:
                    updatedUser["firstName"] + " " + updatedUser["lastName"],
                  accessToken: updatedUser["accessToken"],
                })
              : response(false, "something wrong while updating user data");
        }
      } else {
        const user = await new User({
          firstName: request.firstName,
          lastName: request.lastName,
          emailID: request.emailID,
          password: request.password,
          source: request.source,
          wallet: {
            id: sha256(request.emailID.toUpperCase() + request.source),
          },
          accessToken: request.accessToken,
        });

        user["accessToken"] = jwt.sign(
          {
            user_id: user.id,
            emailID: request.emailID,
            userKey: user.userKey,
          },
          process.env.AUTH_SECRET,
          {
            expiresIn: "100d",
          }
        );

        await user.save();
        const savedUser = await User.findOne({
          emailID: request.emailID,
        }).exec();
        finalResponse = response(true, "Success", {
          username: savedUser["firstName"] + " " + savedUser["lastName"],
          accessToken: savedUser["accessToken"],
        });
      }
    }
  } catch (e) {
    finalResponse = response(false, e.message, {});
  }

  res.status(status.CREATED).send(finalResponse);
});

module.exports = router;
