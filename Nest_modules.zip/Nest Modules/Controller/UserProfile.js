const express = require("express");
const bcrypt = require("bcrypt");
const User = require("../Model/UserSchema");
const status = require("../Utils/NestHTTPStatusCodes");
const route = require("../Utils/NestRoutes");
const { response } = require("../Utils/Response");
const router = express.Router();
const saltRounds = 8;
const NestLog = require("../Logger/NestLog");
const { logBody } = require("../Logger/LogBody");
const { Item } = require("../Model/ItemSchema");
const Grid = require("../Model/ImageGridSchema");
const logger = new NestLog().logger;

/**
 * @param {string} user id
 *
 * @description This function is used to get user profile
 *
 * @returns {object} user profile
 *
 * steps:
 * 1. get user id from request
 * 2. find user by id
 * 3. return user profile
 * */

router.get(route.GET_PROFILE, async (req, res) => {
  logger.info(logBody(req, "Inside user get profile"));
  const user_id = req.user.user_id;
  let finalResult, statusCode;
  try {
    await User.findOne({ _id: user_id })
      .exec()
      .then(async (user) => {
        if (!user) {
          logger.error(logBody(req, "Given user is not registered yet"));
          finalResult = response(false, "Given user is not registered yet", "");
          statusCode = status.BAD_REQUEST;
        } else {
          let obj = {
            user_id: user_id,
            firstName: user.firstName,
            lastName: user.lastName,
            emailID: user.emailID,
            mobile: user.mobile,
            accountDetails: user.accountDetails,
          };
          logger.info(logBody(req, "AllOk user get profile"));
          finalResult = response(true, "success", obj);
          statusCode = status.OK;
        }
      });
  } catch (e) {
    logger.error(logBody(req, "on user sign up", e.message));
    finalResult = response(
      false,
      "Error Occurred Please Check Mandatory Fields!",
      e.message
    );
    statusCode = status.BAD_REQUEST;
  }
  res.status(statusCode).send(finalResult);
});

/**
 * @param {string} user id
 *
 * @description This function is used to update user profile
 *
 * @returns {object} user profile
 *
 * steps:
 * 1. get user id from request
 * 2. find user by id
 * 3. return individual user profile
 * */

router.get(route.INDIVIDUAL_USER, async (req, res) => {
  let finalResponse, user;
  try {
    let userId = req.query.id;
    if (await User.exists({ _id: userId })) {
      user = await User.findById(userId).exec();
      finalResponse = response(true, "success", user);
    } else {
      finalResponse = response(false, "Invalid User Id");
    }
  } catch (e) {
    finalResponse = response(
      false,
      "error occured while fetching individual user records",
      e.message
    );
  }
  res.json(finalResponse);
});

/**
 * @BodyParam {string} itemId
 * @Param userId
 *
 * @description: This function is used to add item to user favourite
 *
 * @returns {object} user profile
 *
 * steps:
 * 1.get itemid from body param
 * 2. get user by userId
 * 3. add itemId to user favourite propery
 * 4. save user
 * 5. return user profile
 * */

router.put(route.ADD_TO_FAVOURITES, async (req, res) => {
  logger.info(logBody(req, "Inside user item favourites"));
  let itemId = req.body.itemId;
  let userId = req.user.user_id;
  let isRemove =
    typeof req.body.isRemove === "boolean" ? req.body.isRemove : false;

  let finalResult, statusCode;

  try {
    let updatedUser;
    if (!isRemove)
      updatedUser = await User.findOneAndUpdate(
        { _id: userId },
        { $addToSet: { favourites: itemId } },
        { new: true }
      );
    else
      updatedUser = await User.findOneAndUpdate(
        { _id: userId },
        { $pull: { favourites: itemId } },
        { new: true }
      );
    if (updatedUser) {
      logger.info(logBody(req, "AllOk user item favourites"));
      finalResult = response(true, "success", updatedUser);
      statusCode = status.OK;
    } else {
      finalResult = response(false, "failure");
      statusCode = status.BAD_REQUEST;
    }
  } catch (e) {
    logger.error(logBody(req, "on user sign up", e.message));
    finalResult = response(false, "failure", e.message);
    statusCode = status.BAD_REQUEST;
  }
  res.status(statusCode).send(finalResult);
});

/**
 * @Param {string} userId
 *
 * @BodyParam {Object} user update details
 *
 * @description: This function is used to update user profile
 *
 * @returns {object} user profile
 * */

router.put(route.UPDATE_PROFILE, async (req, res) => {
  logger.info(logBody(req, "Inside user update profile"));
  let request = req.body,
    finalResult,
    statusCode;
  const user_id = req.user.user_id;
  const filters = { _id: user_id };
  const update = {
    firstName: request.firstName,
    lastName: request.lastName,
    mobile: request.mobile,
    "accountDetails.accountNumber": request.accountNumber
      ? request.accountNumber
      : 0,
    "accountDetails.accountName": request.accountName
      ? request.accountName
      : "",
    "accountDetails.routingNumber": request.routingNumber
      ? request.routingNumber
      : 0,
    updatedAt: Date.now(),
  };
  await User.findOneAndUpdate(filters, update, { new: true })
    .then((result) => {
      logger.info(logBody(req, "AllOk user update profile"));
      finalResult = response(true, "success", result);
      statusCode = status.OK;
    })
    .catch((e) => {
      logger.error(logBody(req, "on user sign up", e.message));
      finalResult = response(
        false,
        "Error Occurred Please Check Mandatory Fields",
        e.message
      );
      statusCode = status.BAD_REQUEST;
    });
  res.status(statusCode).send(finalResult);
});

/**
 * @Param {string} userId
 *
 * @BodyParam {Object} user password change data
 *
 * @description : This function is used to update user password
 *
 * steps:
 * 1. get user by userId
 * 2. check if old password is correct
 * 3. update password
 * 4. return user profile
 * */

router.post(route.CHANGE_PASSWORD, async (req, res) => {
  logger.info(logBody(req, "Inside user chnage password"));
  const { OldPassword, Password, VerifyPassword } = req.body;
  const user_id = req.user.user_id;
  let finalResult, statusCode;
  if (user_id == null || typeof user_id == "undefined" || user_id === "") {
    logger.error(logBody(req, "Error Occurred Please Check User_id missing"));
    finalResult = response(
      false,
      "Error Occurred Please Check Mandatory Fields",
      "User_id missing"
    );
    statusCode = status.CONFLICT;
    res.status(statusCode).send(finalResult);
  } else if (
    OldPassword == null ||
    typeof OldPassword == "undefined" ||
    OldPassword === ""
  ) {
    logger.error(
      logBody(req, "Error Occurred Please Check OldPassword missing")
    );
    finalResult = response(
      false,
      "Error Occurred Please Check Mandatory Fields",
      " OldPassword missing"
    );
    statusCode = status.CONFLICT;
    res.status(statusCode).send(finalResult);
  } else if (
    Password == null ||
    typeof Password == "undefined" ||
    Password === "" ||
    VerifyPassword == null ||
    typeof VerifyPassword == "undefined" ||
    VerifyPassword === ""
  ) {
    logger.error(
      logBody(
        req,
        "Error Occurred Please Check Password or VerifyPassword missing"
      )
    );
    finalResult = response(
      false,
      "Error Occurred Please Check Mandatory Fields",
      "Password or VerifyPassword missing"
    );
    statusCode = status.CONFLICT;
    res.status(statusCode).send(finalResult);
  } else if (Password !== VerifyPassword) {
    logger.error(
      logBody(req, "Error Occurred Please Check new Password no match")
    );
    finalResult = response(
      false,
      "Error Occurred Please Check Mandatory Fields",
      "new password no match"
    );
    statusCode = status.CONFLICT;
    res.status(statusCode).send(finalResult);
  } else if (Password === OldPassword) {
    logger.error(
      logBody(req, "Error Occurred Please Check new Password is same")
    );
    finalResult = response(
      false,
      "Error Occurred Please Check Mandatory Fields",
      "new password is same"
    );
    statusCode = status.CONFLICT;
    res.status(statusCode).send(finalResult);
  } else {
    const filters = { _id: user_id };
    await User.findOne(filters)
      .then(async (Userdetails) => {
        if (!Userdetails) {
          logger.error(logBody(req, "Given user is not registered yet"));
          finalResult = response(false, "Given user is not registered yet", "");
          statusCode = status.NOT_FOUND;
          res.status(statusCode).send(finalResult);
        } else if (
          Userdetails.password == null ||
          typeof Userdetails.password == "undefined" ||
          Userdetails.Password === ""
        ) {
          logger.error(
            logBody(req, "Given user is not registered with password")
          );
          finalResult = response(
            false,
            "Given user is not registered with password",
            ""
          );
          statusCode = status.NOT_FOUND;
          res.status(statusCode).send(finalResult);
        } else {
          await bcrypt.compare(
            OldPassword,
            Userdetails.password,
            async (err, result) => {
              // console.log(err);
              // console.log(result);
              if (result) {
                const update = {
                  password: await bcrypt.hash(Password, saltRounds),
                  updatedAt: Date.now(),
                };
                await User.updateOne(filters, update)
                  .then((result) => {
                    logger.info(logBody(req, "AllOk user chnage password"));
                    finalResult = response(true, "success", result);
                    statusCode = status.OK;
                    res.status(statusCode).send(finalResult);
                  })
                  .catch((e) => {
                    logger.error(
                      logBody(
                        req,
                        "Error Occurred Please Check Mandatory Fields",
                        e.message
                      )
                    );
                    finalResult = response(
                      false,
                      "Error Occurred Please Check Mandatory Fields",
                      e.message
                    );
                    statusCode = status.BAD_REQUEST;
                    res.status(statusCode).send(finalResult);
                  });
              } else {
                logger.error(
                  logBody(req, "current password didn't match", err)
                );
                res
                  .status(status.NOT_FOUND)
                  .send(response(false, "current password didn't match", err));
              }
            }
          );
        }
      })
      .catch((e) => {
        logger.error(logBody(req, "on user change password", e.message));
        finalResult = response(
          false,
          "Error Occurred Please Check Mandatory Fields",
          e.message
        );
        statusCode = status.BAD_REQUEST;
        res.status(statusCode).send(finalResult);
      });
  }
});

/**
 * @param: user_id
 *
 * @description: This function is used to get user details
 *
 * steps:
 * 1. check user_id is valid or not
 * 2. check user is registered or not
 * 3. if user is registered then get user details
 * 4. if user is not registered then send error message
 * 5. if user is registered then update status to deleted
 * 6. if user is deleted then send success message
 * */

router.get(route.VERIFY_USER_DATA, async (req, res) => {
  logger.info(logBody(req, "Inside user data before deleting accountDetails"));
  let finalResult,
    message = "",
    isDataExist = false;
  try {
    let userId = req.user.user_id;

    if (await validateUserWallet(req, userId)) {
      isDataExist = true;
      message =
        "Wallet amount exist in your account. Do you still wanna delete your account?";
    } else if (await validateUserItems(req, userId)) {
      isDataExist = true;
      message =
        "You have active item in marketplace. Do you still wanna delete your account?";
    } else if (await validateResellItemExist(req, userId)) {
      isDataExist = true;
      message =
        "You have active resell units in marketplace, Do you still delete your account?";
    } else {
      isDataExist = true;
      message = "Do you want to delete your account?";
    }

    console.log(`isDataExist: ${isDataExist}`);

    if (isDataExist) {
      finalResult = response(isDataExist, "success", { message });
    } else {
      finalResult = response(isDataExist, "failure", { message });
    }
  } catch (e) {
    finalResult = response(false, "Error occured while processing user data", {
      error: e.message,
    });
  }
  res.json(finalResult);
});

async function validateUserWallet(req, userId) {
  let isWalletAmountExist = false;
  try {
    let user = await User.findById(userId)
      .select({ "wallet.amount": 1 })
      .exec();
    if (user.wallet.amount > 0) {
      isWalletAmountExist = true;
    }
  } catch (e) {
    logger.error(
      logBody(req, "Error occured while processing user wallet data")
    );
  }
  return isWalletAmountExist;
}

async function validateUserItems(req, userId) {
  let isItemIdExist = false;
  try {
    let items = await Item.find({
      uploadedUser: userId,
      isResellAllowed: false,
    })
      .select({ _id: 1 })
      .exec();
    if (items && items.length > 0) {
      isItemIdExist = true;
    }
  } catch (e) {
    logger.error(
      logBody(req, "Error occured while processing validateUserItems")
    );
  }
  return isItemIdExist;
}

async function validateResellItemExist(req, userId) {
  let isResellIdExist = false;
  try {
    let grids = await Grid.find({ sellerId: userId, active: true }).exec();
    if (grids && grids.length > 0) {
      isResellIdExist = true;
    }
  } catch (e) {
    logger.error(logBody(req, "Error occured while validating resell item"));
  }
  return isResellIdExist;
}

router.delete(route.DELETE_USER, async (req, res) => {
  logger.info(logBody(req, "Inside user delete account"));
  let finalResult, statusCode;
  const user_id = req.user.user_id;
  const filters = { _id: user_id };
  const update = {
    status: "Deleted",
    accessToken: " ",
    updatedAt: new Date().toUTCString(),
  };
  await User.findOneAndUpdate(filters, update, { new: true })
    .then((result) => {
      logger.info(logBody(req, "AllOk user delete account"));
      finalResult = response(true, "success", {});
      statusCode = status.OK;
    })
    .catch((e) => {
      logger.error(logBody(req, "on user delete account", e.message));
      finalResult = response(
        false,
        "Error Occurred Please Check Mandatory Fields",
        e.message
      );
      statusCode = status.BAD_REQUEST;
    });
  res.status(statusCode).send(finalResult);
});

router.get(route.GET_ALL_USER, async (req, res) => {
  let finalResponse;
  try {
    let users = await User.find({}).exec();
    finalResponse =
      users.length > 0
        ? response(true, "success", users)
        : response(false, "No user found");
  } catch (e) {
    finalResponse = response(
      false,
      "Something wrong while fetching user details",
      e.message
    );
  }
  res.json(finalResponse);
});

module.exports = router;
